import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: {
      main: '#6200ea',
    },
    secondary: {
      main: '#76ff03',
    },
  },
  mixins: {
    denseToolbar: {
      minHeight: 48
    }
  }
});

export default theme;