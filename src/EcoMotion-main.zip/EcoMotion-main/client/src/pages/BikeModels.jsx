import { useState, useEffect } from 'react';
import http from '../http';
import { Typography, Box, Fab, Stack } from "@mui/material";
// import AspectRatio from '@mui/joy/AspectRatio';
import { Add } from "@mui/icons-material";
import BikeModelCard, 
    { modeltoElementID, smoothScrollingTo, controlScrolltoTarget } 
from '../components/BikeModelCard';

export default function BikeModels() {
    const [bikeModels, setBikeModels] = useState([]);
    const [modelForm, setModelForm] = useState(null);

    function getBikeModels() {
        http.get('/bikeModel/details').then((res) => {
            setBikeModels(res.data);
        });
    };
    useEffect(() => {
        // run in initial render and after rerender when modelForm changes
        if (modelForm) {
            controlScrolltoTarget(modeltoElementID(modelForm))
        }
    }, [modelForm])
    useEffect(() => {
        getBikeModels();        
    }, []);
    useEffect(() => {
        smoothScrollingTo(location.hash.substring(1))
    }, [bikeModels])

    function removeForm() {
        setModelForm(null);
    }
    function onSubmit() {
        removeForm();
        getBikeModels();
    }

    function AddButton(prop) {
        return (
            <Fab color="secondary" aria-label="Add" {...prop}>
                <Add />
            </Fab>
        )
    }

    return (
        <main style={{height: "100%", display: "flex", flexDirection: "column", overflow: "clip"}}>
            <Box justifyContent="center" gap={4} pt={5} mb={2} sx={{ display: 'flex', alignItems: 'center' }}>
                <Typography variant="h3">Bike Models</Typography>
                { (modelForm != "new") && <AddButton onClick={ () => setModelForm("new") }/> }
            </Box>
            <Stack className="bikeModel-stack" spacing={2} alignItems="center" sx={{overflowX: "scroll"}} flexGrow={1}>
                {(modelForm == "new") && (
                    <BikeModelCard form onSubmit={onSubmit} onClose={removeForm} AddButton={AddButton}/>
                )}
                {
                    bikeModels.map((bikeModel) => {
                        return (
                            <BikeModelCard bikeModel={bikeModel} key={bikeModel.id}
                                {...(modelForm && bikeModel.name == modelForm) 
                                    ? { form: true, onSubmit: onSubmit, onClose: removeForm, onDelete: onSubmit }
                                    : { onEdit: () => setModelForm(bikeModel.name), onDelete: getBikeModels }
                                }
                            />
                        )
                    })
                }
                {
                    (bikeModels.length == 0 && !modelForm) && (<Typography>There are currently no bike models</Typography>)
                }
            </Stack>
        </main>
    )
}