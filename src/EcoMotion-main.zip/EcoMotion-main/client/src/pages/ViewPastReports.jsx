// import React, { useEffect, useState } from 'react';
// import { TableContainer, Table, TableHead, TableBody, TableRow, TableCell, IconButton } from '@mui/material';
// import DeleteIcon from '@mui/icons-material/Delete';

// // Sample data for demonstration (replace this with data fetched from the server)
// const sampleReports = [
//   {
//     id: 1,
//     name: 'John Doe',
//     contactNumber: '+123456789',
//     dateOfReport: '2023-07-31',
//     timeOfReport: '15:30',
//     otherDamages: 'Scratches on the body',
//   },
//   {
//     id: 2,
//     name: 'Jane Smith',
//     contactNumber: '+987654321',
//     dateOfReport: '2023-08-01',
//     timeOfReport: '10:15',
//     otherDamages: 'Broken basket',
//   },
// ];

// const CustomerViewPastReports = () => {
//   const [reports, setReports] = useState([]);

//   useEffect(() => {
//     // Simulate fetching reports from the server (replace this with actual API call)
//     fetchReports();
//   }, []);

//   const fetchReports = () => {
//     // Simulate fetching reports from the server (replace this with actual API call)
//     // For demonstration purposes, we are using the sampleReports array as the data source
//     setReports(sampleReports);
//   };

//   const deleteReport = (id) => {
//     // Simulate deleting a report (replace this with actual API call)
//     // For demonstration purposes, we will remove the report from the local state
//     setReports((prevReports) => prevReports.filter((report) => report.id !== id));
//     console.log('Report deleted successfully.');
//   };

//   const sortReports = (field, order) => {
//     const sortedReports = [...reports];

//     if (field === 'id') {
//       sortedReports.sort((a, b) => (order === 'asc' ? a.id - b.id : b.id - a.id));
//     } else if (field === 'date') {
//       sortedReports.sort((a, b) =>
//         order === 'asc'
//           ? new Date(a.dateOfReport) - new Date(b.dateOfReport)
//           : new Date(b.dateOfReport) - new Date(a.dateOfReport)
//       );
//     }

//     setReports(sortedReports);
//   };

//   return (
//     <div className="past-reports-container">
//       <h2>Past Reports</h2>
//       <div>
//         <button onClick={() => sortReports('id', 'asc')}>Sort by ID (Asc)</button>
//         <button onClick={() => sortReports('id', 'desc')}>Sort by ID (Desc)</button>
//         <button onClick={() => sortReports('date', 'asc')}>Sort by Date (Asc)</button>
//         <button onClick={() => sortReports('date', 'desc')}>Sort by Date (Desc)</button>
//       </div>
//       {reports.length > 0 ? (
//         <TableContainer>
//           <Table>
//             <TableHead>
//               <TableRow>
//                 <TableCell>Name</TableCell>
//                 <TableCell>Contact Number</TableCell>
//                 <TableCell>Date</TableCell>
//                 <TableCell>Time</TableCell>
//                 <TableCell>Other Damages</TableCell>
//                 <TableCell>Action</TableCell>
//               </TableRow>
//             </TableHead>
//             <TableBody>
//               {reports.map((report) => (
//                 <TableRow key={report.id}>
//                   <TableCell>{report.name}</TableCell>
//                   <TableCell>{report.contactNumber}</TableCell>
//                   <TableCell>{report.dateOfReport}</TableCell>
//                   <TableCell>{report.timeOfReport}</TableCell>
//                   <TableCell>{report.otherDamages}</TableCell>
//                   <TableCell>
//                     <IconButton onClick={() => deleteReport(report.id)}>
//                       <DeleteIcon />
//                     </IconButton>
//                   </TableCell>
//                 </TableRow>
//               ))}
//             </TableBody>
//           </Table>
//         </TableContainer>
//       ) : (
//         <p>No reports found.</p>
//       )}
//     </div>
//   );
// };

// export default CustomerViewPastReports;

import React, { useState } from 'react';
import {
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  IconButton,
  MenuItem,
  Select,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';

// Sample data for demonstration
const sampleReports = [
  {
    id: 1,
    name: 'John Doe',
    contactNumber: '+1234567890',
    dateOfReport: '2023-08-01',
    timeOfReport: '09:30',
    otherDamages: 'None',
  },
  {
    id: 2,
    name: 'Jane Smith',
    contactNumber: '+9876543210',
    dateOfReport: '2023-08-02',
    timeOfReport: '15:45',
    otherDamages: 'Scratches on the handlebar',
  },
  // Add more sample reports here if needed
];

const CustomerViewPastReports = () => {
  const [reports, setReports] = useState(sampleReports);
  const [sortField, setSortField] = useState('');
  const [sortOrder, setSortOrder] = useState('asc');

  const handleSort = (field) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const sortedReports = reports.sort((a, b) => {
    if (sortField === 'id') {
      return sortOrder === 'asc' ? a.id - b.id : b.id - a.id;
    } else if (sortField === 'date') {
      return sortOrder === 'asc' ? new Date(a.dateOfReport) - new Date(b.dateOfReport) : new Date(b.dateOfReport) - new Date(a.dateOfReport);
    } else if (sortField === 'name') {
      return sortOrder === 'asc' ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name);
    } else if (sortField === 'contactNumber') {
      return sortOrder === 'asc' ? a.contactNumber.localeCompare(b.contactNumber) : b.contactNumber.localeCompare(a.contactNumber);
    }
    return 0;
  });

  // List of sorting options
  const sortingOptions = [
    { label: 'Name (Asc)', value: 'name' },
    { label: 'Name (Desc)', value: '-name' },
    { label: 'Contact Number (Asc)', value: 'contactNumber' },
    { label: 'Contact Number (Desc)', value: '-contactNumber' },
    { label: 'Date (Asc)', value: 'date' },
    { label: 'Date (Desc)', value: '-date' },
  ];

  return (
    <div className="past-reports-container">
      <h2>Past Reports</h2>

      {/* Dropdown menu for sorting */}
      <Select
        value={sortField}
        onChange={(e) => handleSort(e.target.value)}
        label="Sort by"
        style={{ marginBottom: '20px' }}
      >
        {sortingOptions.map((option) => (
          <MenuItem key={option.value} value={option.value}>
            {option.label}
          </MenuItem>
        ))}
      </Select>

      {/* Table */}
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>
                <span onClick={() => handleSort('name')}>Name</span>
                {sortField === 'name' && sortOrder === 'asc' && <ArrowUpwardIcon />}
                {sortField === '-name' && <ArrowDownwardIcon />}
              </TableCell>
              <TableCell>
                <span onClick={() => handleSort('contactNumber')}>Contact Number</span>
                {sortField === 'contactNumber' && sortOrder === 'asc' && <ArrowUpwardIcon />}
                {sortField === '-contactNumber' && <ArrowDownwardIcon />}
              </TableCell>
              <TableCell>
                <span onClick={() => handleSort('date')}>Date</span>
                {sortField === 'date' && sortOrder === 'asc' && <ArrowUpwardIcon />}
                {sortField === '-date' && <ArrowDownwardIcon />}
              </TableCell>
              <TableCell>Time</TableCell>
              <TableCell>Other Damages</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sortedReports.map((report) => (
              <TableRow key={report.id}>
                <TableCell>{report.name}</TableCell>
                <TableCell>{report.contactNumber}</TableCell>
                <TableCell>{report.dateOfReport}</TableCell>
                <TableCell>{report.timeOfReport}</TableCell>
                <TableCell>{report.otherDamages}</TableCell>
                <TableCell>
                  <IconButton onClick={() => setReports((prevReports) => prevReports.filter((r) => r.id !== report.id))} aria-label="delete">
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default CustomerViewPastReports;
