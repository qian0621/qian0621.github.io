// home.jsx
import Map from '../components/Map';
import { Paper, Typography, Slide } from '@mui/material';
import {useEffect, useRef, useState,useContext} from 'react'
import "../styles/Home.css";
import UserContext from '../contexts/UserContext'

export default function Home({welcomeMsg, closeWelcomeMsg}) {
  const welcomeRef = useRef(null);
  const {user} = useContext(UserContext);
  useEffect(() => {
    welcomeRef.current.focus();
  }, []);

  return (
    <main>
      <Slide direction="right" in={welcomeMsg}>
        <Paper ref={welcomeRef} tabIndex="-1" onBlur={closeWelcomeMsg} className="welcomecard">
            <Typography variant="h2">Welcome{user && " " + user.name},</Typography>
            <Typography variant="h6">Let's embrace nature in motion!</Typography>
        </Paper>
      </Slide>
      <Map />
    </main>
  );
}
