import { Outlet, useLoaderData } from "react-router-dom";
import { ThemeProvider } from "@mui/material";
import theme from "../styles/theme";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
//local components
import Navbar from "../components/Navbar";
// user
import UserContext from '../contexts/UserContext'
import { useState } from 'react';
import http from '../http'

export default function Base() {
    const [user, setUser] = useState(useLoaderData());

    return (
        <UserContext.Provider value={{ user, setUser }}>
            <ThemeProvider theme={theme}>
                <header>
                    <Navbar/>
                </header>
                <ToastContainer />
                <Outlet/>
            </ThemeProvider>
        </UserContext.Provider>
    )
}

export async function getUser() {
    return (localStorage?.hasOwnProperty("accessToken"))
        ? (await http.get('/user/auth')).data.user
        : null;
}