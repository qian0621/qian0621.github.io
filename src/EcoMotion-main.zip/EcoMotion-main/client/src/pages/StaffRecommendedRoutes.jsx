// StaffRecommendedRoutes.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const StaffRecommendedRoutes = () => {
  const [recommendedRoutes, setRecommendedRoutes] = useState([]);

  useEffect(() => {
    // Fetch the recommended cycling routes on component mount
    axios
      .get('https://www.onemap.gov.sg/api/public/routingsvc/route?start=1.319728%2C103.8421&end=1.319728905%2C103.8421581&routeType=cycle', {
        headers: {
          Authorization: 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjEwNDAwLCJ1c2VyX2lkIjoxMDQwMCwiZW1haWwiOiJoaWdocmluaXN0dWR5MjdAZ21haWwuY29tIiwiZm9yZXZlciI6ZmFsc2UsImlzcyI6Imh0dHA6XC9cL29tMi5kZmUub25lbWFwLnNnXC9hcGlcL3YyXC91c2VyXC9zZXNzaW9uIiwiaWF0IjoxNjkwODY3Mzc0LCJleHAiOjE2OTEyOTkzNzQsIm5iZiI6MTY5MDg2NzM3NCwianRpIjoiOTE2MWNjMzhiMDc2NTg5ZDVmMzE4ZmI4MzhhZWI5NGEifQ.XYsVNGVjsBMij-Su5V_fGYijTqIlRXViIhE1RWA2o2Y', // Replace with your actual API key
        },
      })
      .then((response) => {
        setRecommendedRoutes(response.data.routes);
      })
      .catch((error) => {
        console.error('Error fetching recommended routes:', error);
      });
  }, []);

  return (
    <div>
      <h2>Recommended Routes Page (Read-only for customers)</h2>
      {/* Display the list of recommended routes */}
      <ul>
        {recommendedRoutes.map((route, index) => (
          <li key={index}>
            {/* Display route details here */}
            <p>Route Name: {route.name}</p>
            <p>Distance: {route.distance}</p>
            {/* Add other route details as needed */}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StaffRecommendedRoutes;
