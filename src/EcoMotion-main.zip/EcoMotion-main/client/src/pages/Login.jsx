import React, { useContext, useEffect, useState } from 'react';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { useNavigate } from 'react-router-dom';
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import http from '../http';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import UserContext from '../contexts/UserContext';
// import { auth, provider } from '../firebase'; // Import the auth object from your firebase.js file
// import { signInWithPopup } from 'firebase/auth';
import { Google } from '@mui/icons-material';


function Login() {

  const navigate = useNavigate();
  const { setUser } = useContext(UserContext);
  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema: yup.object().shape({
      email: yup.string().trim()
        .email('Enter a valid email')
        .max(50, 'Email must be at most 50 characters')
        .required('Email is required'),
      password: yup.string().trim()
        .min(8, 'Password must be at least 8 characters')
        .max(50, 'Password must be at most 50 characters')
        .required('Password is required'),
    }),
    onSubmit: (data) => {
      data.email = data.email.trim().toLowerCase();
      data.password = data.password.trim();
      http.post("/user/login", data)
        .then((res) => {
          localStorage.setItem("accessToken", res.data.accessToken);
          localStorage.setItem("userdata", res.data.user);
          setUser(res.data.user);
          navigate("/");
          window.location.reload();
        })
        .catch(function (err) {
          toast.error(`${err.response.data.message}`);
        });
    }
  });


  const [value, setvalue] = useState('')
  const handleGoogleSignIn = () => {
    signInWithPopup(auth, provider)
      .then((result) => {
        const user = result.user;

        // Set user information in local storage
        localStorage.setItem('name', user.displayName);
        localStorage.setItem('email', user.email);
        localStorage.setItem('role', 'customer'); // Set role to "customer"

        // Update user context
        setUser({
          name: user.displayName,
          email: user.email,
          role: 'customer',
        });
        navigate("/");

        // Display the saved items
        console.log("name:", localStorage.getItem("name"));
        console.log("Role:", localStorage.getItem("role"));
        console.log("Email:", localStorage.getItem("email"));

      })


  }

  useEffect(() => {
    setvalue(localStorage.getItem('email'))

  })

  return (
    <Container component="main" maxWidth="sm">
      <Box
        sx={{
          background: 'white',
          color: 'black',
          boxShadow: 3,
          borderRadius: 2,
          px: 4,
          py: 6,
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>
        <Box component="form" onSubmit={formik.handleSubmit} noValidate sx={{ mt: 1 }}>
          <TextField
            margin="normal"
            required
            fullWidth
            id="email"
            label="Email Address"
            name="email"
            autoComplete="email"
            autoFocus
            value={formik.values.email}
            onChange={formik.handleChange}
            error={formik.touched.email && formik.errors.email}
            helperText={formik.touched.email && formik.errors.email}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            autoComplete="current-password"
            value={formik.values.password}
            onChange={formik.handleChange}
            error={formik.touched.password && formik.errors.password}
            helperText={formik.touched.password && formik.errors.password}
          />
          <FormControlLabel
            control={<Checkbox value="remember" color="primary" />}
            label="Remember me"
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}
          >
            Sign In
          </Button>
          <Button
            variant="contained"
            fullWidth
            sx={{
              backgroundColor: '#4285F4',
              color: '#ffffff',
              boxShadow: 'none',
              textTransform: 'none',
              '&:hover': {
                backgroundColor: '#357AE8',
                boxShadow: 'none',
              },
              mb: 2, // Add margin to the bottom
            }}
            startIcon={<Google />}
            onClick={handleGoogleSignIn}
          >
            Sign In with Google
          </Button>
          <ToastContainer />
          <Grid container spacing={0}>
            <Grid item xs sx={{ textAlign: 'left' }}>
              <Link href="/changepass" variant="body2">
                Forgot password?
              </Link>
            </Grid>
            <Grid item>
              <Link href="/register" variant="body2">
                {"Don't have an account? Sign Up"}
              </Link>
            </Grid>
          </Grid>
        </Box>
      </Box>
    </Container>
  );
}

export default Login;

