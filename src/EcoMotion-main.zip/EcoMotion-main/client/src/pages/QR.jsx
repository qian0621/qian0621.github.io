import { Html5QrcodeScanner, Html5QrcodeScanType } from "html5-qrcode";
import { useEffect, useState ,useContext} from "react";
import axios from "axios";
import UserContext from '../contexts/UserContext';

function QR() {
  const [scanResult, setScanResult] = useState(null);
  const { user } = useContext(UserContext);
  useEffect(() => {
    const scanner = new Html5QrcodeScanner(
      "reader",
      {
        fps: 10,
        qrbox: { width: 100, height: 100 },
        rememberLastUsedCamera: false,
        // supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA],
      },
      false
    );
    scanner.render(success, error);
    function success(result) {
      scanner.clear();

      axios
        .post("http://localhost:3001/qr-scan/"+user.id)
        .then(function (response) {
          console.log(response.data);
        })
        .catch(function (error) {
          console.log(error);
        });

      setScanResult(result);
    }
    function error(err) {
      console.warn(err);
    }
  }, []);

  const qrReaderStyle = {
    width: "300px",
    height: "200px",
    border: "2px solid #333",
    margin: "0 auto",
    marginTop: "20px",
  };

  const headingStyle = {
    marginTop: "60px",
  };
  const successContainerStyle = {
    marginTop: "20px",
    padding: "8px",
    border: "2px solid green",
    borderRadius: "4px", // Add rounded corners to the container box
    width: "300px", // Set a specific width for the container
    margin: "0 auto", // Center the container
  };

  const successMessageStyle = {
    fontSize: "24px",
    color: "green",
  };

  return (
    <div>
      <h1 style={headingStyle}>Scan QR</h1>
      {scanResult ? (
        <div style={successContainerStyle}>
          <div style={successMessageStyle}>Success</div>
        </div>
      ) : (
        <div style={qrReaderStyle} id="reader"></div>
      )}
    </div>
  );
}

export default QR;
