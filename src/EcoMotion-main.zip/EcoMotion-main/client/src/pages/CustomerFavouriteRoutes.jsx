import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import http from '../http';
import { useFormik } from 'formik';
import * as yup from 'yup';


export default function CustomerFavouriteRoutes() {
  const [openDialog, setOpenDialog] = useState(false);
  // const [selectedImage, setSelectedImage] = useState('');

  const handleButtonClick = (category) => {
    setSelectedCategory(category);
    setOpenDialog(true);
  };

  // const handleImageUpload = (e) => {
  //   const uploadedImage = e.target.files[0];
  //   setSelectedImage(URL.createObjectURL(uploadedImage));
  // };

  const formik = useFormik({
    initialValues: {
      start: '',
      end: '',
    },
    validationSchema: yup.object({
      start: yup.string().required('Start is required'),
      end: yup.string().required('End is required'),
    }),
    onSubmit: (values) => {
      handleSubmit(values);
    },
  });

  const handleSubmit = (values) => {
    setOpenDialog(false);

    // Create the form data object
    const formData = {
      start: values.start,
      end: values.end,
    };

    console.log(formData);
    http
      .post('/customerfavouriteroutes', formData)
      .then((response) => {
        // Handle the response from the server
        console.log(response);
        if (response.data && response.data.customerfavouriteroute) {
          toast.success('Form submitted successfully!');
        } else {
          toast.error('Failed to submit the form. Please try again.');
        }
      })
      .catch((error) => {
        console.error('Error submitting form:', error);
        toast.error('An error occurred while submitting the form. Please try again.');
      });
  };

  return (
      <Box
        component="form"
        sx={{
          background: 'white',
          display: 'grid',
          gridTemplateColumns: '1fr',
          gridTemplateRows: 'auto auto 1fr auto',
          gap: '20px',
          alignItems: 'left',
          justifyContent: 'left',
          minHeight: '100vh',
          padding: '50px',
          boxSizing: 'border-box',
        }}
        noValidate
        autoComplete="off"
        onSubmit={formik.handleSubmit}
      >
        <TextField
          fullWidth
          id="start"
          name="start"
          label="Start"
          variant="outlined"
          value={formik.values.name}
          onChange={formik.handleChange}
          error={formik.touched.name && Boolean(formik.errors.name)}
          helperText={formik.touched.name && formik.errors.name}
        />
        <TextField
          fullWidth
          id="end"
          name="end"
          label="End"
          variant="outlined"
          value={formik.values.name}
          onChange={formik.handleChange}
          error={formik.touched.name && Boolean(formik.errors.name)}
          helperText={formik.touched.name && formik.errors.name}
        />

        <Box sx={{ display: 'grid', gridTemplateColumns: '1fr', gap: '0px', justifyContent: 'center' }}>
          <Button type="submit" variant="contained" color="primary" sx={{ width: '50%' }}>
            Submit
          </Button>
        </Box>

        {/* <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
          <DialogTitle>Image Preview</DialogTitle>
          <DialogContent>
            <DialogContentText>Please confirm the selected image:</DialogContentText>
            {selectedImage && (
              <img src={selectedImage} alt="Selected" style={{ width: '100%', height: 'auto' }} />
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
            <Button onClick={() => handleSubmit(formik.values)}>Confirm</Button>
          </DialogActions>
        </Dialog> */}

        <ToastContainer position="top-right" autoClose={3000} hideProgressBar={false} />
      </Box>
  //   </LocalizationProvider>
  );
}
