import { Html5QrcodeScanner, Html5QrcodeScanType } from "html5-qrcode";
import { useEffect } from "react";
import { Typography, Box } from "@mui/material";
import http from '../http';
import "../styles/ScanToRide.css"
import { useNavigate } from "react-router-dom";

const existParam = new URLSearchParams({exist: ""});

export default function ScanToRide() {
  const navigate = useNavigate();
  useEffect(() => {
    const scanner = new Html5QrcodeScanner(
      "reader",
      {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        rememberLastUsedCamera: false,
        supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA],
      },
      false
    );
    scanner.render(success);

    function success(result) {
      scanner.pause(true);
      console.log(result);
      if (result.length > 4 || result.substring(0, 4) === "bike") {
        http.get('/bike/' + result.substring(4)).then(({data}) => {
          console.log(data);
          if (data.status === "available" && data.battery !== 0) {
            scanner.clear();
            navigate("/#bike"+data.id);
          } else {
            alert(`Bike ${data.id} is not available`);
            scanner.resume();
          }
        }).catch((err) => {
          console.log(err);
          if (err.response.status === 404) {
            alert("No bike found");
            scanner.resume();
          }
        });
      } else {
        alert("Invalid QR Code");
        scanner.resume();
      }
    }
  }, []);

  return (
    <main className="scan-to-ride">
      <Typography variant="h3" className="main-header">Scan To Ride</Typography>
      <Box className="scan-container" sx={{width: { xs: "100%", sm: "80%" }}}>
        <div id="reader"/>
      </Box>
    </main>
  );
}