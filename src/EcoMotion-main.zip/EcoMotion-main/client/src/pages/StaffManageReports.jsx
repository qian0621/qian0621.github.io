// import React, { useEffect, useState } from 'react';
// import http from '../http';
// import { Paper, Container, Chip, Dialog, DialogTitle, DialogContent, DialogActions, Button } from '@mui/material';
// import CheckCircleIcon from '@mui/icons-material/CheckCircle';
// import BuildCircleIcon from '@mui/icons-material/BuildCircle';
// import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
// import BlockIcon from '@mui/icons-material/Block';
// import { DataGrid, GridToolbar } from "@mui/x-data-grid";

// const statuses = {
//     Available: { sx: { color: 'green' }, icon: <CheckCircleIcon /> },
//     Unavailable: { sx: { color: 'red' }, icon: <VisibilityOffIcon /> },
//     Maintenance: { sx: { color: 'orange' }, icon: <BuildCircleIcon /> },
//     Retired: { sx: { color: 'grey' }, icon: <BlockIcon /> }
// };

// const columns = [
//     {
//         field: 'id',
//         headerName: 'ID',
//         valueGetter: (params) => params.id.toString(),
//         editable: false,
//         width: 82
//     },
//     {
//         field: 'name',
//         headerName: 'Name',
//         editable: false,
//         width: 150
//     },
//     {
//         field: 'contactNumber',
//         headerName: 'Contact Number',
//         editable: false,
//         width: 140
//     },
//     {
//         field: 'datetimeOfReport',
//         headerName: 'Date and Time of Report',
//         editable: false,
//         width: 200
//     },
//     {
//         field: 'status',
//         type: 'singleSelect',
//         headerName: 'Status',
//         renderCell: (params) => {
//             return <Chip label={params.value} {...statuses[params.value]} />
//         },
//         editable: true,
//         valueOptions: Object.keys(statuses),
//         width: 140
//     },
//     {
//         field: 'actions',
//         headerName: 'Actions',
//         sortable: false,
//         filterable: false,
//         width: 120,
//         renderCell: (params) => {
//             const [open, setOpen] = useState(false);
//             const handleClose = () => setOpen(false);
//             const handleOpen = () => setOpen(true);

//             const handleStatusUpdate = (newStatus) => {
//                 // Perform the status update logic here
//                 const updatedReports = reports.map((report) =>
//                     report.id === params.id ? { ...report, status: newStatus } : report
//                 );
//                 setReports(updatedReports);
//                 handleClose();
//             };

//             return (
//                 <>
//                     <Button variant="outlined" onClick={handleOpen}>Edit</Button>
//                     <Dialog open={open} onClose={handleClose}>
//                         <DialogTitle>Edit Report Status</DialogTitle>
//                         <DialogContent>
//                             {Object.keys(statuses).map((status) => (
//                                 <Button
//                                     key={status}
//                                     onClick={() => handleStatusUpdate(status)}
//                                     color={params.value === status ? 'primary' : 'default'}
//                                     startIcon={statuses[status].icon}
//                                     sx={{ margin: 1 }}
//                                 >
//                                     {status}
//                                 </Button>
//                             ))}
//                         </DialogContent>
//                         <DialogActions>
//                             <Button onClick={handleClose} color="primary">Cancel</Button>
//                         </DialogActions>
//                     </Dialog>
//                 </>
//             );
//         },
//     },
//     // Add more columns if needed
// ];

// export default function CustomerReportsTable() {
//     const [reports, setReports] = useState([]);

//     useEffect(() => {
//         fetchReports();
//     }, []);

//     function fetchReports() {
//         http.get('/reports')
//             .then((response) => {
//                 setReports(response.data);
//             })
//             .catch((error) => {
//                 console.error('Error fetching reports:', error);
//             });
//     }

//     return (
//         <main>
//             <Paper component={Container} sx={{ minWidth: 460, overflow: 'hidden', padding: "0 !important" }}>
//                 <DataGrid
//                     rows={reports}
//                     columns={columns}
//                     autoHeight
//                     components={{
//                         Toolbar: GridToolbar,
//                     }}
//                     disableSelectionOnClick
//                 />
//             </Paper>
//         </main>
//     );
// }

import React, { useEffect, useState } from 'react';
import http from '../http';
import { Paper, Container, Chip } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import BlockIcon from '@mui/icons-material/Block';
import PendingIcon from '@mui/icons-material/Pending';


const statuses = {
  Resolved: {sx:{color: 'green'}, icon: <CheckCircleIcon/>}, 
  Pending: {sx:{color: 'orange'}, icon: <PendingIcon/>},
  Unresolvable: {sx:{color: 'red'}, icon: <BlockIcon/>}
};

const columns = [
    {
        field: 'id',
        headerName: 'ID',
        valueGetter: (params) => params.id.toString(),
        editable: false,
        width: 82
    },
    {
        field: 'name',
        headerName: 'Name',
        editable: false,
        width: 150
    },
    {
        field: 'contactNumber',
        headerName: 'Contact Number',
        editable: false,
        width: 140
    },
    {
        field: 'datetimeOfReport',
        headerName: 'Date and Time of Report',
        editable: false,
        width: 200
    },
    {
        field: 'status',
        type: 'singleSelect',
        headerName: 'Status',
        renderCell: (params) => {
            return <Chip label={params.value} {...statuses[params.value]} />
        },
        editable: true,
        valueOptions: Object.keys(statuses),
        width: 140
    },
    // Add more columns if needed
];

export default function StaffManageReportsTable() {
    const [reports, setReports] = useState([]);

    useEffect(() => {
        fetchReports();
    }, []);

    function fetchReports() {
        http.get('/reports')
            .then((response) => {
                setReports(response.data);
            })
            .catch((error) => {
                console.error('Error fetching reports:', error);
            });
    }

    return (
        <main>
            <Paper component={Container} sx={{ minWidth: 460, overflow: 'hidden', padding: "0 !important" }}>
                <DataGrid
                    rows={reports}
                    columns={columns}
                    autoHeight
                    components={{
                        Toolbar: GridToolbar, // This adds the default toolbar for the grid
                    }}
                    disableSelectionOnClick // Disable row selection when clicked
                    onCellEditCommit={(params, event) => {
                        const { field, value } = event.props;
                        const updatedReports = [...reports];
                        const index = reports.findIndex((report) => report.id === params.id);
                        updatedReports[index] = {
                            ...updatedReports[index],
                            [field]: value
                        };
                        setReports(updatedReports);
                    }}
                />
            </Paper>
        </main>
    );
}

