import React, { useState, useEffect ,useContext} from "react";
import { Link, useLocation } from "react-router-dom";
import axios from "axios";
import "../styles/wallet.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import UserContext from '../contexts/UserContext';

const Wallet = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const message = queryParams.get("message");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [card, setCard] = useState([]);
  const [username, setUsername] = useState("User");
  const [balance, setBalance] = useState("User");
  const [userbalance, setUserBalance] = useState(0);
  const [toputId, setTopupId] = useState();
  const { user } = useContext(UserContext);
  const [formattedNumber, setformattedNumber] = useState("");
  useEffect(() => {

    const fetchData = async () => {
      try {
        const response = await axios.get(
          "http://localhost:3001/api/get/card/"+user.id //we need to add login user id
        );
        console.log(response.data);
        const cardData = response.data[0];
        setCard(response.data);

        let formattedValue = "";
        for (let i = 0; i < cardData.card_number.length; i++) {
          if (i > 0 && i % 4 === 0) {
            formattedValue += " "; // Append a space after every 4 characters
          }
          formattedValue += cardData.card_number[i];
        }
        setformattedNumber(formattedValue);
      } catch (error) {
        console.log(error);
      }
      
    };

    fetchData();

    // for Success Message
    const handleSuccess = (message) => {
      if (message === "add_success") {
        toast.success("Adding Card Success!");
      } else if (message === "update_success") {
        toast.success("Update Card Success!");
      }
      setIsModalOpen(false);
    };
    handleSuccess(message); // Replace this with your logic to set the 'message' variable
    return () => {
      toast.dismiss(); // Dismiss any existing toast notifications when the component is unmounted
    };
  }, []);

  useEffect(()=>{
    const fetchData = async () => {
    try {
      const response = await axios.get(
        "http://localhost:3001/api/get/balance/"+user.id //we need to add login user id
      );
      console.log(response)
      setUserBalance(response.data.balance)
      setUsername(response.data.name)
    } catch (error) {
      console.log(error);
    }}
    fetchData()
  },[])

  const handleDelete = (e, id) => {
    e.preventDefault();
    const fetchData = async () => {
      try {
        const response = await axios.delete(
          `http://localhost:3001/api/delete/card/${id}`
        );
        toast.success("Delete Card Success!");
        let newCard = card.filter((i) => i.id !== id);
        setCard(newCard);
      } catch (error) {
        console.log(error);
      }
    };
    fetchData();
    setIsModalOpen(false);
  };

  const handleClickTP = (id) => {
    setTopupId(id);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const balanceChange = (e) => {
    const value = e.target.value;
    setBalance(value);
  };

  const handlesubmitModel = (e) => {
    e.preventDefault();
    const fetchData = async () => {
      try {
        const response = await axios.put(
          `http://localhost:3001/api/topup/card/${toputId}`,
          {
            balance,
          }
        );
        setBalance("")
        setUserBalance(response.data.balance)
      } catch (error) {
        console.log(error);
      }
    };
    fetchData();
    setIsModalOpen(false);
  };

  return (
    <>
      <div className="container">
        <div>
          <ToastContainer />
        </div>
        <main className="app-screen">
          <header className="app-header">
            <div>
              <h2 style={{ color: "white" }}>Hello {username}</h2>
            </div>
          </header>
          <div style={{ marginTop: 30 }}>
              <span style={{ color: "white" }}>
                Balance : $ {userbalance}
              </span>
            </div>

          {card.length === 0 ? (
            <div style={{ marginTop: 30 }}>
              <span style={{ color: "white" }}>Add new credit card</span>
            </div>
          ) : null}

          {card.map((item, index) => (
            <>
              <Link
                to={{
                  pathname: "/credit_card_form",
                  search: `?id=${item.id}`,
                }}
              >
                <section key={item.id} className="app-card-wrapper">
                  <p style={{ color: "white" }}>
                    Card-{"("}
                    {index + 1}
                    {")"} 
                  </p>
                  <div className="card">
                    <h3 style={{ color: "white" }}>{item.card_number}</h3>
                    <div className="card-date">
                      <p style={{ color: "white" }}>
                        Expiry Date
                        <br />
                        {item.exp_month}||{item.exp_year}
                      </p>
                      <span style={{ color: "white" }}>{item.cvv}</span>
                    </div>
                    <div className="card-details">
                      <p style={{ color: "white" }}>{item.cardholder_name}</p>
                      <span className="card-logo"></span>
                    </div>
                  </div>
                </section>
              </Link>
              <button
                className="button button1"
                onClick={(e) => handleClickTP(item.id)}
              >
                Top up
              </button>
              <button
                className="button button2"
                onClick={(e) => handleDelete(e, item.id)}
              >
                Delete
              </button>
            </>
          ))}

          <section className="app-upcoming-payments-wrapper">
            <div className="upcoming-payments">
              <div>
                <Link to="/credit_card_form">+</Link>
              </div>
            </div>
          </section>
        </main>

        {isModalOpen && (
          <div className="dialog-overlay">
            <div className="dialog-box">
              <h3>Payment</h3>
              <form>
                <label>Enter amount to top up</label>
                <input type="number" value={balance} onChange={balanceChange} />
                <div className="dialog-buttons">
                  <button onClick={handlesubmitModel} type="submit">
                    Confirm
                  </button>
                  <button onClick={handleCloseModal}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default Wallet;