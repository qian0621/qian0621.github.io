// import { useState, useEffect } from 'react';
// import http from '../http';
// import { Typography, Box, Fab, Stack } from "@mui/material";
// // import AspectRatio from '@mui/joy/AspectRatio';
// import { Add } from "@mui/icons-material";
// import ChargingStationModelCard, 
//     { modeltoElementID, smoothScrollingTo, controlScrolltoTarget } 
// from '../components/ChargingStationModelCard';

// export default function ChargingStationModels() {
//     const [chargingstationModels, setChargingStationModels] = useState([]);
//     const [modelForm, setModelForm] = useState(null);

//     function getChargingStationModels() {
//         http.get('/chargingstationModel/details').then((res) => {
//             setChargingStationModels(res.data);
//         });
//     };
//     useEffect(() => {
//         // run in initial render and after rerender when modelForm changes
//         if (modelForm) {
//             controlScrolltoTarget(modeltoElementID(modelForm))
//         }
//     }, [modelForm])
//     useEffect(() => {
//         getChargingStationModels();        
//     }, []);
//     useEffect(() => {
//         smoothScrollingTo(location.hash.substring(1))
//     }, [chargingstationModels])

//     function removeForm() {
//         setModelForm(null);
//     }
//     function onSubmit() {
//         removeForm();
//         getChargingStationModels();
//     }

//     function AddButton(prop) {
//         return (
//             <Fab color="secondary" aria-label="Add" {...prop}>
//                 <Add />
//             </Fab>
//         )
//     }

//     return (
//         <main style={{height: "100%", display: "flex", flexDirection: "column", overflow: "clip"}}>
//             <Box justifyContent="center" gap={4} pt={5} mb={2} sx={{ display: 'flex', alignItems: 'center' }}>
//                 <Typography variant="h3">Charging Station Models</Typography>
//                 { (modelForm != "new") && <AddButton onClick={ () => setModelForm("new") }/> }
//             </Box>
//             <Stack className="chargingstationModel-stack" spacing={2} alignItems="center" sx={{overflowX: "scroll"}} flexGrow={1}>
//                 {(modelForm == "new") && (
//                     <ChargingStationModelCard form onSubmit={onSubmit} onClose={removeForm} AddButton={AddButton}/>
//                 )}
//                 {
//                     chargingstationModels.map((chargingstationModel) => {
//                         return (
//                             <ChargingStationModelCard chargingstationModel={chargingstationModel} key={chargingstationModel.id}
//                                 {...(modelForm && chargingstationModel.name == modelForm) 
//                                     ? { form: true, onSubmit: onSubmit, onClose: removeForm, onDelete: onSubmit }
//                                     : { onEdit: () => setModelForm(chargingstationModel.name), onDelete: getChargingStationModels }
//                                 }
//                             />
//                         )
//                     })
//                 }
//                 {
//                     (chargingstationModels.length == 0 && !modelForm) && (<Typography>There are currently no charging station models</Typography>)
//                 }
//             </Stack>
//         </main>
//     )
// }

import { useState, useEffect } from 'react';
import http from '../http';
import { Typography, Box, Fab, Stack } from "@mui/material";
import { Add } from "@mui/icons-material";
import ChargingStationModelCard,
{ modeltoElementID, smoothScrollingTo, controlScrolltoTarget }
from '../components/ChargingStationModelCard';

const sampleChargingStationModels = [
  {
    id: 1,
    name: "Model 1",
    ampere: 16,
    voltage: 220,
    price_rate: 5.99,
  },
  {
    id: 2,
    name: "Model 2",
    ampere: 16,
    voltage: 221,
    price_rate: 7.49,
  },
  // Add more objects as needed...
];

export default function ChargingStationModels() {
  const [chargingstationModels, setChargingStationModels] = useState(sampleChargingStationModels);
  const [modelForm, setModelForm] = useState(null);

  useEffect(() => {
    if (modelForm) {
      controlScrolltoTarget(modeltoElementID(modelForm));
    }
  }, [modelForm]);

  function removeForm() {
    setModelForm(null);
  }

  function onSubmit() {
    removeForm();
    // In a real scenario, you might make an HTTP request here
  }

  function AddButton(prop) {
    return (
      <Fab color="secondary" aria-label="Add" {...prop}>
        <Add />
      </Fab>
    );
  }

  return (
    <main style={{ height: "100%", display: "flex", flexDirection: "column", overflow: "clip" }}>
      <Box justifyContent="center" gap={4} pt={5} mb={2} sx={{ display: 'flex', alignItems: 'center' }}>
        <Typography variant="h3">Charging Station Models</Typography>
        { (modelForm !== "new") && <AddButton onClick={() => setModelForm("new")} /> }
      </Box>
      <Stack className="chargingstationModel-stack" spacing={2} alignItems="center" sx={{ overflowX: "scroll" }} flexGrow={1}>
        {(modelForm === "new") && (
          <ChargingStationModelCard form onSubmit={onSubmit} onClose={removeForm} AddButton={AddButton} />
        )}
        {
          chargingstationModels.map((chargingstationModel) => (
            <ChargingStationModelCard
              chargingstationModel={chargingstationModel}
              key={chargingstationModel.id}
              {...(modelForm && chargingstationModel.name === modelForm) 
                ? { form: true, onSubmit: onSubmit, onClose: removeForm, onDelete: onSubmit }
                : { onEdit: () => setModelForm(chargingstationModel.name), onDelete: () => {/* Implement onDelete logic */} }
              }
            />
          ))
        }
        {
          (chargingstationModels.length === 0 && !modelForm) && (<Typography>There are currently no charging station models</Typography>)
        }
      </Stack>
    </main>
  );
}
