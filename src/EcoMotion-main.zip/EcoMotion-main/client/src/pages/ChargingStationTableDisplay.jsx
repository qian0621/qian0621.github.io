// // checked the case of the letters
// // fixed 

// import { Typography, Box, Fab } from "@mui/material";
// import { useState, useEffect } from 'react';
// import http from '../http';
// import { Add } from "@mui/icons-material";
// import { Paper, Container, Chip } from '@mui/material';
// import { DataGrid, GridActionsCellItem } from "@mui/x-data-grid"
// import { Link } from "react-router-dom";
// import BatteryGauge from "../components/BatteryGauge";
// import ChargingStationForm, { getChargingStationModels, toTitleCase } from "../components/ChargingStationForm";
// import { modeltoElementID } from "../components/ChargingStationModelCard";
// import BuildCircleIcon from '@mui/icons-material/BuildCircle';
// import CheckCircleIcon from '@mui/icons-material/CheckCircle';
// import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
// import BlockIcon from '@mui/icons-material/Block';
// import DeleteIcon from '@mui/icons-material/Delete';
// import { toast } from 'react-toastify';

// const statuses = {
//     available: {color: 'success', icon: <CheckCircleIcon/>}, 
//     unavailable: {color: 'error', icon: <VisibilityOffIcon/>}, 
//     maintenance: {color: 'warning', icon: <BuildCircleIcon/>},
//     retired: {icon: <BlockIcon/>}
// };

// const statusOptions = []
// for (const status in statuses) {
//     statusOptions.push({value: status, label: toTitleCase(status)});
// }

// const modelColI = 1;


// function AddButton(prop) {
//     return (
//         <Fab color="secondary" aria-label="Add" {...prop}>
//             <Add />
//         </Fab>
//     )
// }

// export default function ChargingStationTableDisplay() {
//     const [chargingstations, setChargingStations] = useState([]);
//     const [form, setForm] = useState(false);
    
//     function getChargingStations() {
//         http.get('/chargingstation').then((res) => {
//             setChargingStations(res.data);
//         });
//     };
//     useEffect(() => {
//         getChargingStationModels((res) => {
//             const ChargingStationModelCol = columns[modelColI];
//             const chargingstationModels = res.data;
//             console.log(chargingstationModels);
//             ChargingStationModelCol.valueGetter = (params) => chargingstationModels.find((model) => model.id === params.value).name;
//             ChargingStationModelCol.valueOptions = chargingstationModels;
//             ChargingStationModelCol.getOptionValue = (value) => value.id;
//             ChargingStationModelCol.getOptionLabel = (value) => value.name;
//             setColumns([...columns.slice(0, modelColI), ChargingStationModelCol, ...columns.slice(modelColI + 1)])
//         });
//         getChargingStations();
//     }, []);

//     function deleteChargingStation(id) {
//         if (confirm(`Are you sure you want to delete charging station ${id}?`)) {
//             http.delete("/chargingstation/" + id)
//                 .then((res) => {
//                     toast.success(res.data.message);
//                     getChargingStations();
//                 }).catch(function (error) {
//                     console.log(error.response);
//                     toast.error(error.response.data.message);
//                 });
//         }
//     }

//     const chargingstationColumns = [
//         {
//             field: 'id',
//             headerName: 'ID',
//             valueGetter: (params) => params.id.toString(),
//             editable: false,
//             flex: 1
//         }, 
//         {
//             field: 'model_id',
//             headerName: 'Model',
//             type: 'singleSelect',
//             editable: false,
//             renderCell: (params) => (
//                 <Link to={"/chargingstationModels#" + modeltoElementID(params.value)}>{params.value}</Link>
//             ),
//             flex: 4
//         }, 
//         {
//             field: 'status',
//             type: 'singleSelect',
//             headerName: 'Status',
//             valueFormatter: ({value}) => toTitleCase(value),
//             renderCell: (params) => <Chip label={params.formattedValue} variant="outlined" {...statuses[params.value]}/>,
//             editable: true,
//             valueOptions: statusOptions,
//             minWidth: 160,
//             flex: 3
//         },
//         {
//             field: 'battery',
//             headerName: 'Battery',
//             type: 'number',
//             renderCell: (params) => 
//                 <BatteryGauge 
//                     level={params.value} 
//                     charging={Boolean(params.row.charging) || params.row.charging === null} 
//                     fontSize="0.875rem"
//                 />,
//             editable: false,
//             minWidth: 81,
//             flex: 2
//         },
//         {
//             field: 'location',
//             headerName: 'Location',
//             valueFormatter: ({value}) => {if (value) return value.coordinates[0] + ", " + value.coordinates[1]},
//             editable: false,
//             sortable: false,
//             flex: 6
//         },
//         {
//             field: 'Delete',
//             type: 'actions',
//             getActions: (params) => [
//                 <GridActionsCellItem
//                   icon={<DeleteIcon />}
//                   label="Delete"
//                   color="error"
//                   onClick={() => deleteChargingStation(params.id)}
//                 />,
//             ],
//             width: 80,
//         }
//     ];
    
//     const [columns, setColumns] = useState(chargingstationColumns);

//     function openForm() {
//         setForm(true);
//     }
//     function closeForm() {
//         setForm(false);
//     }

//     return (
//         <main>
//             <Box justifyContent="center" gap={4} sx={{ display: 'flex', alignItems: 'center', mb: 2, mt: 5 }}>
//                 <Typography variant="h4">Charging Stations</Typography>
//                 <AddButton onClick={openForm}/>
//             </Box>
//             <ChargingStationForm open={form} onClose={closeForm} onSubmit={getChargingStations} AddButton={AddButton}/>
//             <Paper component={Container} sx={{ minWidth: 460, overflow: 'hidden', padding: "0 !important"}}>
//                 <DataGrid columns={columns} rows={chargingstations}/>
//             </Paper>
//         </main>
//     )
// }
import { Typography, Box, Fab } from "@mui/material";
import { useState, useEffect } from 'react';
import http from '../http';
import { Add } from "@mui/icons-material";
import { Paper, Container, Chip } from '@mui/material';
import { DataGrid, GridActionsCellItem } from "@mui/x-data-grid"
import { Link } from "react-router-dom";
import BatteryGauge from "../components/BatteryGauge";
import ChargingStationForm, { getChargingStationModels, toTitleCase } from "../components/ChargingStationForm";
import { modeltoElementID } from "../components/ChargingStationModelCard";
import BuildCircleIcon from '@mui/icons-material/BuildCircle';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import BlockIcon from '@mui/icons-material/Block';
import DeleteIcon from '@mui/icons-material/Delete';
import { toast } from 'react-toastify';

const statuses = {
    available: {color: 'success', icon: <CheckCircleIcon/>}, 
    unavailable: {color: 'error', icon: <VisibilityOffIcon/>}, 
    maintenance: {color: 'warning', icon: <BuildCircleIcon/>},
    retired: {icon: <BlockIcon/>}
};

const statusOptions = []
for (const status in statuses) {
    statusOptions.push({value: status, label: toTitleCase(status)});
}

const modelColI = 1;

const sampleChargingStationModels = [
  {
    id: 1,
    name: "Model 1",
    ampere: 16,
    voltage: 220,
    price_rate: 5.99,
  },
  {
    id: 2,
    name: "Model 2",
    ampere: 16,
    voltage: 221,
    price_rate: 7.49,
  },
  // Add more objects as needed...
];

function AddButton(prop) {
    return (
        <Fab color="secondary" aria-label="Add" {...prop}>
            <Add />
        </Fab>
    )
}

export default function ChargingStationTableDisplay() {
    const [chargingstations, setChargingStations] = useState([]);
    const [form, setForm] = useState(false);
    
    function getChargingStations() {
        http.get('/chargingstation').then((res) => {
            setChargingStations(res.data);
        });
    };
    useEffect(() => {
        getChargingStationModels((res) => {
            const ChargingStationModelCol = columns[modelColI];
            const chargingstationModels = res.data.concat(sampleChargingStationModels);
            ChargingStationModelCol.valueGetter = (params) => chargingstationModels.find((model) => model.id === params.value).name;
            ChargingStationModelCol.valueOptions = chargingstationModels;
            ChargingStationModelCol.getOptionValue = (value) => value.id;
            ChargingStationModelCol.getOptionLabel = (value) => value.name;
            setColumns([...columns.slice(0, modelColI), ChargingStationModelCol, ...columns.slice(modelColI + 1)])
        });
        getChargingStations();
    }, []);

    function deleteChargingStation(id) {
        if (window.confirm(`Are you sure you want to delete charging station ${id}?`)) {
            http.delete("/chargingstation/" + id)
                .then((res) => {
                    toast.success(res.data.message);
                    getChargingStations();
                }).catch(function (error) {
                    console.log(error.response);
                    toast.error(error.response.data.message);
                });
        }
    }

    const chargingstationColumns = [
        // ... (existing columns definitions)
    ];
    
    const [columns, setColumns] = useState(chargingstationColumns);

    function openForm() {
        setForm(true);
    }
    function closeForm() {
        setForm(false);
    }

    return (
        <main>
            <Box justifyContent="center" gap={4} sx={{ display: 'flex', alignItems: 'center', mb: 2, mt: 5 }}>
                <Typography variant="h4">Charging Stations</Typography>
                <AddButton onClick={openForm}/>
            </Box>
            <ChargingStationForm open={form} onClose={closeForm} onSubmit={getChargingStations} AddButton={AddButton}/>
            <Paper component={Container} sx={{ minWidth: 460, overflow: 'hidden', padding: "0 !important"}}>
                <DataGrid columns={columns} rows={chargingstations}/>
            </Paper>
        </main>
    )
}
