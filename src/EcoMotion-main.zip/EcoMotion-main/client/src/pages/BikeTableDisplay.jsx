import { useState, useEffect, useCallback } from 'react';
import http from '../http';
import { Typography, Box, Fab, Paper, Container, Chip } from '@mui/material';
import { DataGrid, GridActionsCellItem } from "@mui/x-data-grid"
import { Link } from "react-router-dom";
import BatteryGauge from "../components/BatteryGauge";
import BikeForm, { getBikeModels, toTitleCase } from "../components/BikeForm";
import { modeltoElementID } from "../components/BikeModelCard";
import AddIcon from "@mui/icons-material/Add";
import BuildCircleIcon from '@mui/icons-material/BuildCircle';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import BlockIcon from '@mui/icons-material/Block';
import DeleteIcon from '@mui/icons-material/Delete';
import { toast } from 'react-toastify';

const statuses = {
    available: {color: 'success', icon: <CheckCircleIcon/>}, 
    unavailable: {color: 'error', icon: <VisibilityOffIcon/>}, 
    maintenance: {color: 'warning', icon: <BuildCircleIcon/>},
    retired: {icon: <BlockIcon/>}
};

const statusOptions = []
for (const status in statuses) {
    statusOptions.push({value: status, label: toTitleCase(status)});
}

const modelColI = 1;

function AddButton(prop) {
    return (
        <Fab color="secondary" aria-label="Add" {...prop}>
            <AddIcon />
        </Fab>
    )
}

export default function BikeTableDisplay() {
    const [bikes, setBikes] = useState([]);
    const [form, setForm] = useState(false);
    
    function getBikes() {
        http.get('/bike').then((res) => {
            setBikes(res.data);
        });
    };
    useEffect(() => {
        getBikeModels((res) => {
            const BikeModelCol = columns[modelColI];
            const bikeModels = res.data;
            // console.log(bikeModels);
            BikeModelCol.valueGetter = (params) => bikeModels.find((model) => model.id === params.value).name;
            BikeModelCol.valueOptions = bikeModels;
            BikeModelCol.getOptionValue = (value) => value.id;
            BikeModelCol.getOptionLabel = (value) => value.name;
            setColumns([...columns.slice(0, modelColI), BikeModelCol, ...columns.slice(modelColI + 1)])
        });
        getBikes();
    }, []);

    function deleteBike(id) {
        if (confirm(`Are you sure you want to delete bike ${id}?`)) {
            http.delete("/bike/" + id)
                .then((res) => {
                    toast.success(res.data.message);
                    getBikes();
                }).catch(function (error) {
                    console.log(error.response);
                    toast.error(error.response.data.message);
                });
        }
    }

    const updateBike = useCallback(async (updatedRow, originalRow) => {
        console.log(updatedRow);
        for (const key in updatedRow) {
            if (updatedRow[key] !== originalRow[key]) {
                // console.log("/bike/" + originalRow.id, {[key]: updatedRow[key]})
                const res = await http.patch("/bike/" + originalRow.id, {[key]: updatedRow[key]})
                console.log(res)
                toast.success(res.data.message);
                return updatedRow;
            }
        }
        return originalRow;
    }, []);

    const updateError = useCallback((error) => {
        console.log(error);
        // toast.error(error.response.data.message);
    }, []);

    const bikeColumns = [
        {
            field: 'id',
            headerName: 'ID',
            valueGetter: ({id}) => id.toString(),
            editable: false,
            flex: 1
        }, 
        {
            field: 'model_id',
            headerName: 'Model',
            type: 'singleSelect',
            editable: false,
            renderCell: ({value}) => <Link to={"/bikeModels#" + modeltoElementID(value)}>{value}</Link>,
            flex: 4
        }, 
        {
            field: 'status',
            type: 'singleSelect',
            headerName: 'Status',
            valueFormatter: ({value}) => toTitleCase(value),
            renderCell: ({formattedValue, value}) => <Chip label={formattedValue} variant="outlined" {...statuses[value]}/>,
            editable: true,
            valueOptions: statusOptions,
            minWidth: 160,
            flex: 3
        },
        {
            field: 'battery',
            headerName: 'Battery',
            type: 'number',
            renderCell: ({row, value}) => 
                <BatteryGauge 
                    level={value} 
                    charging={Boolean(row.charging) || row.charging === null} 
                    fontSize="0.875rem"
                />,
            editable: false,
            minWidth: 81,
            flex: 2
        },
        {
            field: 'location',
            headerName: 'Location',
            valueFormatter: ({value}) => {if (value) return value.coordinates[0].toFixed(7) + ", " + value.coordinates[1].toFixed(7)},
            renderCell: ({id, formattedValue}) => <Link to={"/#bike" + id}>{formattedValue}</Link>,
            editable: false,
            sortable: false,
            flex: 6
        },
        {
            field: 'Delete',
            type: 'actions',
            getActions: ({id}) => [
                <GridActionsCellItem
                  icon={<DeleteIcon />}
                  label="Delete"
                  color="error"
                  onClick={() => deleteBike(id)}
                />,
            ],
            width: 80,
        }
    ];

    const [columns, setColumns] = useState(bikeColumns);

    function openForm() {
        setForm(true);
    }
    function closeForm() {
        setForm(false);
    }

    return (
        <main>
            <Box justifyContent="center" mt={5} mb={2} gap={4} sx={{ display: 'flex', alignItems: 'center' }}>
                <Typography variant="h4">Bikes</Typography>
                <AddButton onClick={openForm}/>
            </Box>
            <BikeForm open={form} onClose={closeForm} onSubmit={getBikes} AddButton={AddButton}/>
            <Paper component={Container} sx={{ minWidth: 460, overflow: 'hidden', padding: "0 !important"}}>
                <DataGrid columns={columns} rows={bikes} processRowUpdate={updateBike} onProcessRowUpdateError={updateError}/>
            </Paper>
        </main>
    )
}
