// import React, { useEffect, useState } from 'react';
// import http from '../http';
// import { Paper, Container, Chip } from '@mui/material';
// import CheckCircleIcon from '@mui/icons-material/CheckCircle';
// import BuildCircleIcon from '@mui/icons-material/BuildCircle';
// import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
// import BlockIcon from '@mui/icons-material/Block';
// import { DataGrid, GridToolbar } from "@mui/x-data-grid";

// const statuses = {
//     Available: { sx: { color: 'green' }, icon: <CheckCircleIcon /> },
//     Unavailable: { sx: { color: 'red' }, icon: <VisibilityOffIcon /> },
//     Maintenance: { sx: { color: 'orange' }, icon: <BuildCircleIcon /> },
//     Retired: { sx: { color: 'grey' }, icon: <BlockIcon /> }
// };

// const columns = [
//     {
//         field: 'id',
//         headerName: 'ID',
//         valueGetter: (params) => params.id.toString(),
//         editable: false,
//         width: 82
//     },
//     {
//         field: 'name',
//         headerName: 'Name',
//         editable: false,
//         width: 150
//     },
//     {
//         field: 'contactNumber',
//         headerName: 'Contact Number',
//         editable: false,
//         width: 140
//     },
//     {
//         field: 'datetimeOfReport',
//         headerName: 'Date and Time of Report',
//         editable: false,
//         width: 200
//     },
//     {
//         field: 'status',
//         type: 'singleSelect',
//         headerName: 'Status',
//         renderCell: (params) => {
//             return <Chip label={params.value} {...statuses[params.value]} />
//         },
//         editable: true,
//         valueOptions: Object.keys(statuses),
//         width: 140
//     },
//     // Add more columns if needed
// ];

// export default function CustomerReportsTable() {
//     const [reports, setReports] = useState([]);

//     useEffect(() => {
//         fetchReports();
//     }, []);

//     function fetchReports() {
//         http.get('/reports')
//             .then((response) => {
//                 setReports(response.data);
//             })
//             .catch((error) => {
//                 console.error('Error fetching reports:', error);
//             });
//     }

//     return (
//         <main>
//             <Paper component={Container} sx={{ minWidth: 460, overflow: 'hidden', padding: "0 !important" }}>
//                 <DataGrid
//                     rows={reports}
//                     columns={columns}
//                     autoHeight
//                     components={{
//                         Toolbar: GridToolbar, // This adds the default toolbar for the grid
//                     }}
//                     disableSelectionOnClick // Disable row selection when clicked
//                     onCellEditCommit={(params, event) => {
//                         const { field, value } = event.props;
//                         const updatedReports = [...reports];
//                         const index = reports.findIndex((report) => report.id === params.id);
//                         updatedReports[index] = {
//                             ...updatedReports[index],
//                             [field]: value
//                         };
//                         setReports(updatedReports);
//                     }}
//                 />
//             </Paper>
//         </main>
//     );
// }
import React, { useEffect, useState } from 'react';
import http from '../http';
import { Paper, Container, Chip } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DataGrid } from "@mui/x-data-grid";
import PendingIcon from '@mui/icons-material/Pending';
import BlockIcon from '@mui/icons-material/Block';

const statuses = {
    Resolved: {sx:{color: 'green'}, icon: <CheckCircleIcon/>}, 
    Pending: {sx:{color: 'orange'}, icon: <PendingIcon/>},
    Unresolvable: {sx:{color: 'red'}, icon: <BlockIcon/>}
};

const columns = [
    {
        field: 'id',
        headerName: 'ID',
        valueGetter: (params) => params.id.toString(),
        width: 82
    },
    {
        field: 'name',
        headerName: 'Name',
        width: 150
    },
    {
        field: 'contactNumber',
        headerName: 'Contact Number',
        width: 140
    },
    {
        field: 'datetimeOfReport',
        headerName: 'Date and Time of Report',
        width: 200
    },
    {
        field: 'status',
        headerName: 'Status',
        renderCell: (params) => {
            return <Chip label={params.value} {...statuses[params.value]} />
        },
        width: 140
    },
    // Add more columns if needed
];

export default function CustomerReportsTable() {
    const [reports, setReports] = useState([]);

    useEffect(() => {
        fetchReports();
    }, []);

    function fetchReports() {
        http.get('/reports')
            .then((response) => {
                setReports(response.data);
            })
            .catch((error) => {
                console.error('Error fetching reports:', error);
            });
    }

    return (
        <main>
            <Paper component={Container} sx={{ minWidth: 460, overflow: 'hidden', padding: "0 !important" }}>
                <DataGrid
                    rows={reports}
                    columns={columns}
                    autoHeight
                    disableSelectionOnClick // Disable row selection when clicked
                />
            </Paper>
        </main>
    );
}
