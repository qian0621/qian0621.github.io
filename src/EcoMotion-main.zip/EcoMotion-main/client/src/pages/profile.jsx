import React, { useState, useContext } from 'react';
import { Box, Typography, Container, useTheme, Grid, Button, Avatar } from '@mui/material';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import UserContext from '../contexts/UserContext';
import http from '../http'; // Import your HTTP service for API calls
import axios from 'axios'; // Import axios

function Profile() {
  const { user, setUser } = useContext(UserContext);
  const theme = useTheme();
  const [profileImage, setProfileImage] = useState(null);

  const handleImageUpload = async (event) => {
    try {
      const file = event.target.files[0];
      const formData = new FormData();
      formData.append('image', file);

      // Replace 'uploadImage' with the actual API endpoint that handles image upload
      const response = await uploadImage(formData);
      const imageUrl = response.data.url; // Assuming the API returns the image URL

      setProfileImage(imageUrl);
    } catch (error) {
      console.error('Error uploading image:', error);
    }
  };

  const handleDeleteAccount = async (accountId) => {
    try {
      console.log('Deleting account with ID:', accountId);

      if (!accountId) {
        console.error('Invalid account ID:', accountId);
        return;
      }

      confirmAlert({
        title: 'Confirm Deletion',
        message: 'Are you sure you want to delete this account?',
        buttons: [
          {
            label: 'Yes',
            onClick: async () => {
              try {
                const response = await http.delete(`/user/accounts/${accountId}`);

                console.log('Deleted account:', response.data);

                if (response.status === 200) {
                  console.log(response.data.message);
                  localStorage.clear();
                  setUser(null);
                  window.location = "/";
                  // Handle successful deletion, e.g., redirect the user
                } else {
                  console.error('Failed to delete account:', response.data.message);
                  // Handle error here
                }
              } catch (error) {
                console.error('Error deleting account:', error);
                // Handle error here
              }
            }
          },
          {
            label: 'No',
            onClick: () => { }
          }
        ]
      });
    } catch (error) {
      console.error('Error deleting account:', error);
    }
  };



  return (
    <Container component="main" maxWidth="sm">
      <Box
        sx={{
          background: 'white',
          color: 'black',
          boxShadow: 3,
          borderRadius: 2,
          px: 4,
          py: 6,
          marginTop: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Typography
          component="h1"
          variant="h5"
          sx={{
            fontWeight: 'bold',
            fontSize: theme.typography.h5.fontSize,
            marginBottom: theme.spacing(5),
          }}
        >
          My Profile
        </Typography>
        {/* Profile Image */}
        <Avatar
          src={profileImage || '/path/to/default/profile/image'}
          sx={{
            width: theme.spacing(10),
            height: theme.spacing(10),
            marginBottom: theme.spacing(2),
          }}
        />

        <label htmlFor="upload-input">
          <input
            id="upload-input"
            type="file"
            accept="image/*"
            style={{ display: 'none' }}
            onChange={handleImageUpload}
          />
          <Button variant="contained" color="primary" component="span">
            Upload Image
          </Button>
        </label>

        <Grid container alignItems="center" spacing={2} sx={{ marginBottom: theme.spacing(2) }}>
          <Grid item>
            <Typography>Name:</Typography>
          </Grid>
          <Grid item>
            <Box
              sx={{
                border: '1px solid lightgray',
                borderRadius: '4px',
                padding: '8px',
              }}
            >
              <Typography>{user?.name}</Typography>
            </Box>
          </Grid>
        </Grid>
        <Grid container alignItems="center" spacing={2} sx={{ marginBottom: theme.spacing(2) }}>
          <Grid item>
            <Typography>Email:</Typography>
          </Grid>
          <Grid item>
            <Box
              sx={{
                border: '1px solid lightgray',
                borderRadius: '4px',
                padding: '8px',
              }}
            >
              <Typography>{user?.email}</Typography>
            </Box>
          </Grid>
        </Grid>
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            marginBottom: theme.spacing(2),
          }}
        >
          <Button
            variant="contained"
            color="primary"
            onClick={() => (window.location = '/wallet')}
            sx={{
              marginRight: theme.spacing(2),
            }}
          >
            Wallet
          </Button>

          <Button
            variant="contained"
            color="primary"
            onClick={() => (window.location = '/ride-history')}
            sx={{
              marginRight: theme.spacing(2),
            }}
          >
            Ride History
          </Button>

          <Button
            variant="contained"
            color="primary"
            onClick={() => (window.location = '/invoice')}
          >
            Invoices
          </Button>
        </Box>

        <Button
          variant="contained"
          color="secondary"
          onClick={() => handleDeleteAccount(user.id)}
          sx={{
            backgroundColor: 'red',
            '&:hover': { backgroundColor: 'red' },
            marginBottom: theme.spacing(2),
          }}
        >
          Delete Account
        </Button>
      </Box>
    </Container>
  );
}

export default Profile;
