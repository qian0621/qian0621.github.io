import React, { useState } from 'react';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { ToastContainer, toast } from 'react-toastify';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import dayjs from 'dayjs';
import 'react-toastify/dist/ReactToastify.css';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import http from '../http';
import { useFormik } from 'formik';
import * as yup from 'yup';
import { MuiTelInput } from 'mui-tel-input';

const today = dayjs();
const yesterday = dayjs().subtract(1, 'day');
const todayStartOfTheDay = today.startOf('day');

const categories = [
  'Battery',
  'Basket',
  'Brake',
  'Chain',
  'Charging Station',
  'Lock',
  'Pedal',
  'Seat',
  'Stand',
  'Tyre',
];

export default function CustomerReportDamages() {
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedImage, setSelectedImage] = useState('');

  const handleButtonClick = (category) => {
    setSelectedCategory(category);
    setOpenDialog(true);
  };

  const handleImageUpload = (e) => {
    const uploadedImage = e.target.files[0];
    setSelectedImage(URL.createObjectURL(uploadedImage));
  };

  const formik = useFormik({
    initialValues: {
      name: '',
      contactNumber: '',
      datetimeOfReport: '',
      otherDamages: '',
    },
    validationSchema: yup.object({
      name: yup.string().trim().max(100, 'Name must be at most 100 characters').required('Name is required'),
      contactNumber: yup.string().required('Contact number is required'),
      datetimeOfReport: yup.date().required('Date and Time of report is required'),
    }),
    onSubmit: (values) => {
      handleSubmit(values);
    },
  });

  const handleSubmit = (values) => {
    setOpenDialog(false);

    // Create the form data object
    const formData = {
      name: values.name,
      contactNumber: values.contactNumber,
      datetimeOfReport: values.datetimeOfReport,
      selectedCategory: selectedCategory,
      selectedImage: selectedImage,
      otherDamages: values.otherDamages,
    };

    console.log(formData);
    http
      .post('/reports', formData)
      .then((response) => {
        // Handle the response from the server
        console.log(response);
        if (response.data && response.data.report) {
          toast.success('Form submitted successfully!');
        } else {
          toast.error('Failed to submit the form. Please try again.');
        }
      })
      .catch((error) => {
        console.error('Error submitting form:', error);
        toast.error('An error occurred while submitting the form. Please try again.');
      });
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box
        component="form"
        sx={{
          background: 'white',
          display: 'grid',
          gridTemplateColumns: '1fr',
          gridTemplateRows: 'auto auto 1fr auto',
          gap: '20px',
          alignItems: 'left',
          justifyContent: 'left',
          minHeight: '100vh',
          padding: '50px',
          boxSizing: 'border-box',
        }}
        noValidate
        autoComplete="off"
        onSubmit={formik.handleSubmit}
      >
        <TextField
          fullWidth
          id="name"
          name="name"
          label="Name"
          variant="outlined"
          value={formik.values.name}
          onChange={formik.handleChange}
          error={formik.touched.name && Boolean(formik.errors.name)}
          helperText={formik.touched.name && formik.errors.name}
        />

        <MuiTelInput
          fullWidth
          id="contactNumber"
          name="contactNumber"
          label="Contact Number"
          variant="outlined"
          value={formik.values.contactNumber}
          onChange={(value) => formik.setFieldValue('contactNumber', value)}
          error={formik.touched.contactNumber && Boolean(formik.errors.contactNumber)}
          helperText={formik.touched.contactNumber && formik.errors.contactNumber}
        />

        <DateTimePicker
          fullWidth
          label="Date and Time of Report"
          value={formik.values.datetimeOfReport}
          onChange={(newValue) => formik.setFieldValue('datetimeOfReport', newValue)}
          minDateTime={yesterday}
          maxDateTime={todayStartOfTheDay}
          renderInput={(params) => <TextField {...params} variant="outlined" />}
          error={formik.touched.datetimeOfReport && Boolean(formik.errors.datetimeOfReport)}
          helperText={formik.touched.datetimeOfReport && formik.errors.datetimeOfReport}
        />

        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '20px', justifyContent: 'center' }}>
          {categories.slice(0, 5).map((category) => (
            <Button
              key={category}
              variant="contained"
              component="label"
              name={category}
              onClick={() => handleButtonClick(category)}
              sx={{ width: '100%' }}
            >
              {category}
              <input type="file" hidden onChange={handleImageUpload} />
            </Button>
          ))}
        </Box>

        <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: '20px', justifyContent: 'center' }}>
          {categories.slice(5).map((category) => (
            <Button
              key={category}
              variant="contained"
              component="label"
              name={category}
              onClick={() => handleButtonClick(category)}
              sx={{ width: '100%' }}
            >
              {category}
              <input type="file" hidden onChange={handleImageUpload} />
            </Button>
          ))}
        </Box>

        <TextField
          fullWidth
          id="otherDamages"
          name="otherDamages"
          label="Other Damages"
          variant="outlined"
          multiline
          rows={4}
          value={formik.values.otherDamages}
          onChange={formik.handleChange}
        />

        <Box sx={{ display: 'grid', gridTemplateColumns: '1fr', gap: '20px', justifyContent: 'center' }}>
          <Button type="submit" variant="contained" color="primary" sx={{ width: '100%' }}>
            Submit
          </Button>
        </Box>

        <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
          <DialogTitle>Image Preview</DialogTitle>
          <DialogContent>
            <DialogContentText>Please confirm the selected image:</DialogContentText>
            {selectedImage && (
              <img src={selectedImage} alt="Selected" style={{ width: '100%', height: 'auto' }} />
            )}
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
            <Button onClick={() => handleSubmit(formik.values)}>Confirm</Button>
          </DialogActions>
        </Dialog>

        <ToastContainer position="top-right" autoClose={3000} hideProgressBar={false} />
      </Box>
    </LocalizationProvider>
  );
}
