import React, { useEffect, useState } from 'react';
import http from '../http';
import { Paper, Container, Chip } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { DataGrid } from "@mui/x-data-grid";
import PendingIcon from '@mui/icons-material/Pending';
import BlockIcon from '@mui/icons-material/Block';

const statuses = {
    Resolved: {sx:{color: 'green'}, icon: <CheckCircleIcon/>}, 
    Pending: {sx:{color: 'orange'}, icon: <PendingIcon/>},
    Unresolvable: {sx:{color: 'red'}, icon: <BlockIcon/>}
};

const columns = [
    {
        field: 'id',
        headerName: 'ID',
        valueGetter: (params) => params.id.toString(),
        width: 82
    },
    {
        field: 'start',
        headerName: 'Start',
        width: 150
    },
    {
        field: 'end',
        headerName: 'End',
        width: 140
    },
    {
        field: 'status',
        headerName: 'Status',
        renderCell: (params) => {
            return <Chip label={params.value} {...statuses[params.value]} />
        },
        width: 140
    },
    // Add more columns if needed
];

export default function CustomerFavouriteRoutesTable() {
    const [customerfavouriteroutes, setCustomerFavouriteRoutes] = useState([]);

    useEffect(() => {
        fetchCustomerFavouriteRoutes();
    }, []);

    function fetchCustomerFavouriteRoutes() {
        http.get('/customerfavouriteroutes')
            .then((response) => {
                setCustomerFavouriteRoutes(response.data);
            })
            .catch((error) => {
                console.error('Error fetching favourite routes:', error);
            });
    }

    return (
        <main>
            <Paper component={Container} sx={{ minWidth: 460, overflow: 'hidden', padding: "0 !important" }}>
                <DataGrid
                    rows={customerfavouriteroutes}
                    columns={columns}
                    autoHeight
                    disableSelectionOnClick // Disable row selection when clicked
                />
            </Paper>
        </main>
    );
}
