// this is for staff
import { useEffect, useState } from "react";
import "../styles/wallet_form.css";
import { useParams } from "react-router-dom";
import axios from "axios";
const WalletForm = () => {
  const { id } = useParams();
  const [cardHolderName, setCardHolderName] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [cardMonth, setCardMonth] = useState("");
  const [cardYear, setCardYear] = useState("");
  const [CVC, setCVC] = useState("");
  const [balance, setBalance] = useState("");

  const handleCardNameChange = (e) => {
    setCardHolderName(e.target.value);
  };

  const handleCardNumberChange = (e) => {
    const value = e.target.value;
    setCardNumber(value);
  };

  const handleCardMmChange = (e) => {
    const value = e.target.value;
    setCardMonth(value);
  };

  const handleCardYyChange = (e) => {
    const value = e.target.value;
    setCardYear(value);
  };

  const handleCardcvcchange = (e) => {
    setCVC(e.target.value);
  };

  const handleBalance = (e) => {
    setBalance(e.target.value);
  };

  const handleSelectChange = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:3001/api/update/card/${id}`, {
        cardHolderName,
        cardNumber,
        cardMonth,
        cardYear,
        CVC,
        balance,
      })
      .then(function (response) {
        console.log(response.data);
        if (response.data == "success") {
          window.location.href = "/walletTable";
        }
        toast.error("Error!", {
          autoClose: 2000, // Set the timeout in milliseconds (e.g., 3000 = 3 seconds)
        });
      })

      .catch(function (error) {
        console.log("error", error);
      });
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "http://localhost:3001/api/get/card" //we need to add login user id
        );
        const cardData = response.data[0];
        setCardHolderName(cardData.cardholder_name);
        setCardNumber(cardData.card_number);
        setCardMonth(cardData.exp_month);
        setCardYear(cardData.exp_year);
        setCVC(cardData.cvv);
        setBalance(cardData.balance);
      } catch (error) {
        console.log(error);
      }
    };
    fetchData();
  }, []);

  return (
    <>
      <div className="form_wrapper">
        <div className="form_container">
          <div className="title_container">
            <h2>Card Form</h2>
          </div>
          <div className="row clearfix">
            <div>
              <div>
                <div className="input_field">
                  <input
                    type="text"
                    maxLength="30"
                    placeholder="Your Name"
                    value={cardHolderName}
                    onChange={handleCardNameChange}
                    required
                  />
                </div>
                <div className="input_field">
                  <input
                    type="text"
                    maxLength="16"
                    placeholder="0000000000000000"
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    required
                  />
                </div>
                <div className="row clearfix">
                  <div className="col_half">
                    <div className="input_field">
                      <input
                        type="text"
                        maxLength="2"
                        placeholder="EXP_Month"
                        value={cardMonth}
                        onChange={handleCardMmChange}
                        required
                      />
                    </div>
                  </div>
                  <div className="col_half">
                    <div className="input_field">
                      <input
                        type="text"
                        maxLength="2"
                        placeholder="EXP_Year"
                        value={cardYear}
                        onChange={handleCardYyChange}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="input_field">
                  <input
                    type="text"
                    maxLength="3"
                    placeholder="CVC"
                    value={CVC}
                    onChange={handleCardcvcchange}
                    required
                  />
                </div>
                <input
                  onClick={handleSelectChange}
                  type="submit"
                  value="Update"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default WalletForm;
