//library components
import { createBrowserRouter, RouterProvider } from "react-router-dom";
//pages
import Base, {getUser} from "./pages/Base";
import Home from "./pages/Home";
import Register from "./pages/Register";
import Login from "./pages/Login";
import Accounts from "./pages/accounts";
import Changepass from "./pages/changepass";
import Profile from "./pages/profile";
import BikeModels from "./pages/BikeModels";
import BikeTableDisplay from "./pages/BikeTableDisplay";
import ChargingStationModels from "./pages/ChargingStationModels";
import ChargingStationTableDisplay from "./pages/ChargingStationTableDisplay";
import PaymentList from "./pages/PaymentList";
import Invoice from "./pages/invoice";
import Wallet from "./pages/Wallet";
import CreditCardForm from "./pages/credit_card_form";
import WalletTable from "./pages/WalletTable";
import InvoiceTable from "./pages/invoiceTable";
import WalletForm from "./pages/Wallet_form";
import QR from "./pages/QR";
import CustomerFavouriteRoutes from './pages/CustomerFavouriteRoutes';
import StaffRecommendedRoutes from './pages/StaffRecommendedRoutes';
import CustomerReportDamages from "./pages/CustomerReportDamages";
import StaffManageReports from "./pages/StaffManageReports";
import CustomerReportsTable from "./pages/CustomerReportsTable";
import Adminpage from "./pages/adminpage";
import TopUp from "./pages/TopUp";
import ScanToRide from "./pages/ScanToRide";
import { useState } from 'react';
import CustomerFavouriteRoutesTable from "./pages/CustomerFavouriteRoutesTable";


function App() {
  const [welcomeMsg, setWelcomeMsg] = useState(true);
  function closeWelcomeMsg() { setWelcomeMsg(false); }
  const router = createBrowserRouter([{
      path: "/", 
      element: <Base/>,
      loader: getUser, 
      children: [
        { index: true, element: <Home welcomeMsg={welcomeMsg} closeWelcomeMsg={closeWelcomeMsg}/> },
        { path: "/login", element: <Login/> },
        { path: "/register", element: <Register/> },
        { path: "/changepass", element: <Changepass/> },
        { path: "/accounts", element: <Accounts/> },
        { path: "/profile", element: <Profile/> },
        { path: "/payment", element: <PaymentList/> },
        { path: "/submitreport", element: <CustomerReportDamages/> },
        { path: "/customerreportstable", element: <CustomerReportsTable/> },
        { path: "/managereports", element: <StaffManageReports/> },
        { path: "/staffrecommendedroutes", element: <StaffRecommendedRoutes/> },
        { path: "/customerfavouriteroutes", element: <CustomerFavouriteRoutes/> },
        { path: "/customerfavouriteroutestable", element: <CustomerFavouriteRoutesTable/> },
        { path: "/wallet", element: <Wallet/> },
        { path: "/invoice", element: <Invoice/> },
        { path: "/credit_card_form", element: <CreditCardForm/> },
        { path: "/walletTable", element: <WalletTable/> },
        { path: "/invoiceTable", element: <InvoiceTable/> },
        { path: "/walletForm/:id", element: <WalletForm/> },
        { path: "/bikeModels", element: <BikeModels/> },
        { path: "/bikes", element: <BikeTableDisplay/> },
        { path: "/chargingstationModels", element: <ChargingStationModels/> },
        { path: "/chargingstations", element: <ChargingStationTableDisplay/> },
        { path: "/qr", element: <QR/> },
        { path: "/topup", element: <TopUp/> },
        { path: "adminpage", element: <Adminpage/> },
        { path: "/scanToRide", element: <ScanToRide/> }
    ]
  }]);
  return <RouterProvider router={router} />;
}

export default App;
