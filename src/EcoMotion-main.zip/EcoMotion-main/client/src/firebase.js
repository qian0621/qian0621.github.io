// import { initializeApp } from "firebase/app";
// import {getAuth,GoogleAuthProvider} from "firebase/auth"

// const firebaseConfig = {
//   apiKey: "AIzaSyBril3MF1z3--YFjkLpjX8jRZWCz7Wz-jA",
//   authDomain: "ecomotion-c8b2d.firebaseapp.com",
//   projectId: "ecomotion-c8b2d",
//   storageBucket: "ecomotion-c8b2d.appspot.com",
//   messagingSenderId: "4167378046",
//   appId: "1:4167378046:web:66b4d908d8992f6864642f",
//   measurementId: "G-5SZFNVCK3Q"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// const auth = getAuth(app);
// const provider = new GoogleAuthProvider()   
// export {auth,provider}