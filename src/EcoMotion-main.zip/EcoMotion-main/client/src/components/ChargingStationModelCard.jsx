// checked the case of the letters
// updated 
// import * as React from 'react';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardMedia, CardActions, IconButton, TextField, Button, InputAdornment, Box } from "@mui/material";
import { Done, Edit, EditOff, Cancel, Delete } from "@mui/icons-material";
import { LocationOn as LocationOnIcon } from '@mui/icons-material';
import "../styles/ChargingStationModelCard.css";
import { toast } from 'react-toastify';
import http from '../http';
import { useFormik } from 'formik';
import * as yup from 'yup';
// import ColorRadioButtons from "./ColorRadioButtons";

export const modeltoElementID = (name) => encodeURI(name);

export function smoothScrollingTo(elementID) {
    document.getElementById(elementID)?.scrollIntoView(
        { behavior: "smooth", block: "nearest" }
    );
}

export function controlScrolltoTarget(elementID) {
    const urlFragment = "#" + elementID;
    if (location.hash !== "" && location.hash !== urlFragment) {
        history.pushState(null, null, urlFragment);
    }
    smoothScrollingTo(elementID);
}

export default function ChargingStationModelCard({ chargingstationModel, form, AddButton, onEdit, onSubmit, onClose, onDelete }) {
    if (!chargingstationModel) {
        if (!form) throw new Error("form is required for new Charging Station models");
        if (!AddButton) throw new Error("add is required for new Charging Station models");
        if (onEdit) throw new Error("onEdit is only valid for existing Charging Station models");
        if (onDelete) throw new Error("onDelete is only valid for existing Charging Station models");
    }
    if (!form) {
        if (onSubmit) throw new Error("onSubmit is only valid for forms");
        if (onClose) throw new Error("onClose is only valid for forms");
    }
    
    const [imageFile, setImageFile] = useState(chargingstationModel?.image_file);
    const [address, setAddress] = useState(chargingstationModel?.address ?? '');

    function handleDelete() {
        if (chargingstationModel.total_chargingstations !== 0) throw new Error("Cannot delete Charging Station model with Charging Stations");
        if (confirm(`Are you sure you want to delete ${chargingstationModel.name}?`)) {
            http.delete("/chargingstationModel/" + chargingstationModel.id)
                .then((res) => {
                    toast.success(res.data.message);
                    onDelete();
                }).catch(function (error) {
                    console.log(error.response);
                    toast.error(error.response.data.message);
                });
        }
    }
    
    function onFileChange(e) {
        let file = e.target.files[0];
        if (file) {
            if (file.size > 1024 * 1024) {
                toast.error('Maximum file size is 1MB');
                //ToastContainer set up in App.jsx
                return;
            }

            let formData = new FormData();
            formData.append('file', file);
            
            http.post('/file/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }).then((res) => {
                setImageFile(res.data.filename);
            }).catch(function (error) {
                console.log(error.response);
            });
        }
    };

    const formik = useFormik({
        initialValues: {
            name: chargingstationModel?.name ?? "",
            ampere: chargingstationModel?.ampere ?? "",
            voltage: chargingstationModel?.voltage ?? "",
            price_rate: chargingstationModel?.price_rate ?? "",
        },
        validationSchema: yup.object({
            name: yup.string().trim()
                .max(100, 'Name must be at most 100 characters')
                .required('Name is required'),
            ampere: yup.number()
                .min(16, 'Ampere must be at least 16A')
                .max(48, 'Maximum ampere level is 48A')
                .required('Ampere is required'),
            voltage: yup.number()
                .min(220, 'Voltage must be at least 220V')
                .max(480, 'Maximum voltage level is 480V')
                .required('Voltage is required'),
            watts: yup.number()
                .min(3.52, 'Watts must be at least 3.52kW')
                .max(23.04, 'Maximum watts level is 23.04kW')
                .required('Watts is required'),
            price_rate: yup.number()
                .max(9.99, 'Maximum price rate is $9.99')
                .required("Price must be set"),
            address: yup.string().trim()
                .required('Address is required'),
        }),
        onSubmit: (data) => {
            if (imageFile) {
                data.image_file = imageFile;
            }
            data.name = data.name.trim();
            data.watts = (data.ampere * data.voltage) / 1000;
            var url = "/chargingstationModel";
            var method;
            var targetID
            if (chargingstationModel) {
                method = "put";
                targetID = chargingstationModel.name;
                url += "/" + chargingstationModel.id;
            } else {
                method = "post";
            }
            http[method](url, data)
                .then((res) => {
                    console.log(res.data);
                    toast.success(res.data.message ?? res.data.name + " was added successfully");
                    onSubmit();
                    controlScrolltoTarget(modeltoElementID(targetID ?? res.data.name));
                }).catch(function (error) {
                    console.log(error.response);
                    toast.error(error.response.data.message);
                });
        }
    });

    return (
        <Card
            id={modeltoElementID(chargingstationModel?.name ?? "new")}
            {...(form) ? { component: "form", onSubmit: formik.handleSubmit } : {} }
            sx={{ width: 475 }}
        >
            <CardHeader
                {...(form) 
                    ? {avatar: (
                        <IconButton aria-label="Cancel" type="button" onClick={onClose} color="error" size="large">
                            {(chargingstationModel) ? <EditOff />: <Cancel />}
                        </IconButton>
                    )} : {} }
                title={ (form) 
                    ? (
                        <Box display="flex" alignItems="center" justifyContent="space-evenly">
                            <TextField 
                                label="Name" 
                                name="name" 
                                required 
                                size="small" 
                                sx={{minWidth: "15ch"}}
                                value={formik.values.name}
                                onChange={formik.handleChange}
                                error={formik.touched.name && Boolean(formik.errors.name)}
                                helperText={formik.touched.name && formik.errors.name}
                            />
                            <Button variant="outlined" component="label" sx={{whiteSpace: "nowrap"}}>
                                Upload Image
                                <input hidden accept="image/*" multiple type="file" onChange={onFileChange} />
                            </Button>
                        </Box>
                    ) : chargingstationModel.name
                }
                action={(AddButton)? <AddButton type="submit" /> :
                    <IconButton
                        aria-label={ (form) ? "Done" : "Edit" } 
                        {...(form) ? {type: "submit", color: "success"} : {type: "button", onClick: onEdit, color: "warning"}}
                    >
                        {(form) ? <Done /> : <Edit />}
                    </IconButton>
                }
            />

            <CardMedia className="model-card-media">
                {imageFile ? (
                    <img
                        src={`${import.meta.env.VITE_FILE_BASE_URL}${imageFile}`} 
                        alt={chargingstationModel?.name ?? "Uploaded Charging Station image"}
                        loading="lazy"
                    />
                ) : (
                    <div className="img-placeholder">
                        No image uploaded
                    </div>
                )}
            </CardMedia>
            <TextField
                    InputProps={{
                        startAdornment: <InputAdornment position="start"><LocationOnIcon color="primary"/></InputAdornment>,
                    }}
                    variant="filled" 
                    size="small" 
                    hiddenLabel 
                    fullWidth 
                    value={address}
                    name="address" 
                    required 
                    onChange={(e) => setAddress(e.target.value)}
                    error={formik.touched.address && Boolean(formik.errors.address)}
                    helperText={formik.touched.address && formik.errors.address}
                    placeholder="Enter Address"
                />

            <CardContent>
                <TextField
                    InputProps={{
                        startAdornment: <InputAdornment position="start">Ampere: </InputAdornment>,
                        endAdornment: <InputAdornment position="end">A</InputAdornment>,
                    }}
                    variant="filled" 
                    size="small" 
                    hiddenLabel 
                    fullWidth 
                    value={formik.values.ampere}
                    name="ampere" 
                    required 
                    type="number" 
                    onChange={formik.handleChange}
                    error={formik.touched.ampere && Boolean(formik.errors.ampere)}
                    helperText={formik.touched.ampere && formik.errors.ampere}
                />

                <TextField
                    InputProps={{
                        startAdornment: <InputAdornment position="start">Voltage: </InputAdornment>,
                        endAdornment: <InputAdornment position="end">V</InputAdornment>,
                    }}
                    variant="filled" 
                    size="small" 
                    hiddenLabel 
                    fullWidth 
                    value={formik.values.voltage}
                    name="voltage" 
                    required 
                    type="number" 
                    onChange={formik.handleChange}
                    error={formik.touched.voltage && Boolean(formik.errors.voltage)}
                    helperText={formik.touched.voltage && formik.errors.voltage}
                />

                <TextField
                    InputProps={{
                        startAdornment: <InputAdornment position="start">Watts: </InputAdornment>,
                        endAdornment: <InputAdornment position="end">kW</InputAdornment>,
                    }}
                    variant="filled" 
                    size="small" 
                    hiddenLabel 
                    fullWidth 
                    value={(formik.values.ampere * formik.values.voltage) / 1000} // Calculate watts in kW
                    name="watts" 
                    required 
                    readOnly={true}
                    type="number" 
                    onChange={formik.handleChange}
                    error={formik.touched.watts && Boolean(formik.errors.watts)}
                    helperText={formik.touched.watts && formik.errors.watts}
                />

                <TextField
                    InputProps={{
                        startAdornment: <InputAdornment position="start">Price: $</InputAdornment>,
                        endAdornment: <InputAdornment position="end">/ 30min</InputAdornment>,
                    }}
                    variant="filled" 
                    size="small" 
                    hiddenLabel 
                    fullWidth 
                    value={formik.values.price_rate}
                    name="price_rate" 
                    required 
                    type="number" 
                    onChange={formik.handleChange}
                    error={formik.touched.price_rate && Boolean(formik.errors.price_rate)}
                    helperText={formik.touched.price_rate && formik.errors.price_rate}
                />

            {/* <ColorRadioButtons /> */}

            </CardContent>

            { chargingstationModel && (
                <CardActions disableSpacing>
                    {(chargingstationModel.total_chargingstations === 0) ? (
                        <Button variant="contained" color="error" onClick={handleDelete} startIcon={<Delete />}>
                            Delete
                        </Button>
                    ) : (
                        <Button variant="text" color="info" href="/chargingstations">{chargingstationModel.total_chargingstations} chargingstation(s) in use</Button>
                    )}
                </CardActions>
            )}
        </Card>
    );
}
