import { useState, useEffect } from 'react';
import http from '../http';
//components
import { CardContent, CardHeader, CardMedia, CardActions, IconButton, Button, Stack, Box, Typography, Skeleton } from "@mui/material";
import BatteryGauge from './BatteryGauge';
//leaflet
import { useMap } from 'react-leaflet/hooks';
//icons
import CloseIcon from '@mui/icons-material/Close';
import FavoriteIcon from '@mui/icons-material/Favorite';
import LockIcon from '@mui/icons-material/Lock';
//styles
import "../styles/BikePopup.css";

export default function BikeCardContent({id}) {
    const [bike, setBike] = useState(null);
    const map = useMap()
    function getBike() {
        http.get('/bike/' + id).then((res) => {
            setBike(res.data);
        });
    };
    useEffect(() => {
        getBike();
    }, []);

    function favourite() {
        //use context to access user
        console.log(bike.id);
    }
    function closePopup() {
        map.closePopup();
    }

    return (
        <>
            <CardHeader
                avatar={
                    <IconButton aria-label="Close" onClick={closePopup}>
                        <CloseIcon/>
                    </IconButton>
                }
                title={"ID: " + id }
                subheader={ bike?.BikeModel.name ?? 
                    <Skeleton width="40%"/>
                }
                action={
                    <IconButton aria-label="Favorite" onClick={favourite}>
                        <FavoriteIcon/>
                    </IconButton>
                }
                sx={{p: 1}}
            />
            { bike?.BikeModel.image_file && (
                <CardMedia
                    className="model-card-media"
                    component="img"
                    src={`${import.meta.env.VITE_FILE_BASE_URL}${bike.BikeModel.image_file}`} 
                    alt="Bike Model"
                />
            )}
            <CardContent sx={{ px: 2, py: 0}}>
                <Stack
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                >
                    <Box>
                        <Typography variant="overline" display="block">Est Range</Typography>
                        <Typography variant="body1" fontSize="1.2rem">{(bike)
                            ? Math.round(bike.battery / bike.BikeModel.battery_per_km) + " km"
                            : <Skeleton />
                        }</Typography>
                    </Box>
                    {(bike?.battery) 
                        ? <BatteryGauge level={bike.battery} charging={bike.charging} fontSize="1.4em"/>
                        : <Skeleton width="6.1em" height="2.94em"/>
                    }
                </Stack>
                <Typography variant="h6">{
                    (bike) ? `$ ${bike.BikeModel.price_rate} / 30 min` : <Skeleton/>
                }</Typography>
            </CardContent>
            <CardActions disableSpacing sx={{display: "block"}}>
                <Button variant="contained" startIcon={<LockIcon />} fullWidth>
                    Unlock & Ride
                </Button>
                <Button variant="text" size="small" href="/submitreport">Report Damages</Button>
            </CardActions>
        </>
    );
}
