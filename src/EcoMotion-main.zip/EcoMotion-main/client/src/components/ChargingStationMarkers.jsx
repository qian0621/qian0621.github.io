// fixed case
// checked spelling

import { useState, useEffect, useRef } from 'react';
import http from '../http';
//leaflet
import { Marker, Popup, Pane } from 'react-leaflet';
import { Icon } from 'leaflet';
import { useMapEvents } from 'react-leaflet/hooks';
import { Card } from "@mui/material";
import ChargingStationCardContent from './ChargingStationCardContent';

const chargingstationIcon = new Icon({
    iconUrl: "/chargingstationMarker.svg",
    iconSize: [24,36], // size of the icon
    iconAnchor:   [12, 36], // point of the icon which will correspond to marker's location
    popupAnchor:  [0, -6], // point from which the popup should open relative to the iconAnchor
    className: 'chargingstation-marker-icon'
})

const locationRelUrl = '/chargingstation/locations?' + new URLSearchParams({status: 'Available,Charging'});
const chargingstationPaneDefaultZindex = 600;

export default function ChargingStationMarkers() {
    const [chargingstations, setChargingStations] = useState([]);
    const openPopups = useRef([]);
    function getChargingStations() {
        http.get(locationRelUrl).then((res) => {
            setChargingStations(res.data);
        });
    };
    useEffect(() => {
        getChargingStations();
    }, []);

    const map = useMapEvents({
        popupopen: (e) => {
            openPopups.current.push(e.popup.options.pane);
            e.popup.getPane().style.zIndex = chargingstationPaneDefaultZindex + openPopups.current.length;
        },
        popupclose: (e) => {
            openPopups.current.splice(openPopups.current.indexOf(e.popup.options.pane), 1);
            e.popup.getPane().style.zIndex = chargingstationPaneDefaultZindex;
        }
    })

    return chargingstations.map((chargingstation) => {
        return (
            <Pane className='chargingstation-pane' key={chargingstation.id} name={`chargingstation${chargingstation.id}Pane`} style={{ zIndex: chargingstationPaneDefaultZindex }}>
                <Marker id={"chargingstation" + chargingstation.id} position={chargingstation.location.coordinates.slice().reverse()} icon={chargingstationIcon}>
                    <Card variant="outlined" className='chargingstation-popup'
                        component={Popup} closeButton={false} interactive bubblingMouseEvents={false}
                    >
                        <ChargingStationCardContent id={chargingstation.id}/>
                    </Card>
                </Marker>
            </Pane>
        )
    });
}
