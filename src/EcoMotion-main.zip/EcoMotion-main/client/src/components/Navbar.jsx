import { useState, Fragment, useContext } from "react";
import { styled } from '@mui/material/styles';
//library components
import {
  AppBar,
  Toolbar,        
  Typography,
  Box,
  IconButton,
  SvgIcon,
  Button,
  Tooltip,
  Menu,
  MenuItem,
  SwipeableDrawer,
  Divider,
  List,
  ListItemButton,
  ListItemText,
  Collapse
} from "@mui/material";
//local components
import Search from "./Search";
import AccountStatus from "./AccountStatus";
//library icons
import MenuIcon from "@mui/icons-material/Menu";
import SearchIcon from "@mui/icons-material/Search";
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
//local icons
import { ReactComponent as EcoMotionNavIcon } from "../assets/Ecomotion.svg";
//styles
import UserContext from '../contexts/UserContext';
import { Link, useNavigate } from 'react-router-dom';
// find nearest bike function
import http from '../http';
import { toast } from 'react-toastify';

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  // necessary for content to be below app bar
  ...theme.mixins.denseToolbar,
}));

function unaccessibleLocation({code}) {
  switch (code) {
    case 1:
      toast.error("You denied access to your location. Try Again?");
      break;
    case 2:
      toast.error("Your location is unavailable. Try Again?");
      break;
    case 3:
      toast.error("Your location request timed out. Try Again?");
      break;
    default:
      toast.error("Your location cannot be accessed to find the nearest bike. Try Again?");
  }
}

export default function Navbar() {
  const navigate = useNavigate();
  function navToNearestBike() { 
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(findNearestBike, unaccessibleLocation, { timeout: 5000, maximumAge: 10000 });
    } else unaccessibleLocation();
  }
  function findNearestBike({coords: {latitude, longitude}}) {
    http.get(
        "/bike/nearest?" 
        + new URLSearchParams({near: latitude + "," + longitude})
    ).then( ({data: {id}}) => navigate("/#bike" + id) );
  }

  var navItems;
  var navStyling;
  const { user } = useContext(UserContext);
  const [openDrawer, setOpenDrawer] = useState(null);
  if (user) {
    if (user.role == "admin") {
      navItems = [
        { content: "Home", props: {component: Link, to: "/"} },
        { content: "Account", dropdown: {
          items: [
            { content: "All Accounts", props: {component: Link, to: "/accounts"} },
            { content: "Admin", props: {component: Link, to: "/adminpage"} },
          ]
        }},
        { content: "Invoice", props: {component: Link, to: "/invoiceTable"} },
        { content: "Cards", props: {component: Link, to: "/walletTable"} },
        { content: "TopUp List", props: {component: Link, to: "/topup"} },
        { content: "Bikes", dropdown: {
          items: [
            { content: "Bikes", props: {component: Link, to: "/bikes"} },
            { content: "Bike Models", props: {component: Link, to: "/bikeModels"} },
          ]
        }},
        { content: "Charging Station", dropdown: {
          items: [
            { content: "Charging Stations", props: {component: Link, to: "/chargingstations"} },
            { content: "Charging Station Models", props: {component: Link, to: "/chargingstationModels"} },
          ]
        }},
        { content: "Reports", props: {component: Link, to: "/managereports"} },
      ];
      navStyling = { color: "white", backgroundColor: "green" };
    } else {
      navItems = [
        { content: "Home", props: {component: Link, to: "/"} },
        { content: "Ride", dropdown: {
          items: [
            {content: "Scan QR Code", props: {component: Link, to: "/scanToRide"}},
            {content: "Find Nearest Bike", onClick: navToNearestBike},
            {content: "Add Favourite Routes", props: {component: Link, to: "/customerfavouriteroutes"}  },
            {content: "My Favourite Routes", props: {component: Link, to: "/customerfavouriteroutestable"}  },
          ]
        }},
        { content: "Invoice", props: {component: Link, to: "/invoice"} },
        {
          content: "Reports", dropdown: {
            items: [
              { content: "Submit Report", props: {component: Link, to: "/submitreport"} },
              { content: "View Past Reports", props: {component: Link, to: "/customerreportstable"} },
            ]
          }
        },
        { content: "Wallet", props: {component: Link, to: "/wallet"} },
      ];
      navStyling = { color: "white", backgroundColor: "#5600E8" };
    }
  } else {
    navItems = [
      { content: "Home", props: {component: Link, to: "/"} },
    ]
    navStyling = { color: "white", backgroundColor: "black" };
  }


  const dropdownStates = {}
  const nestedListStates = {}
  for (const navItem in navItems) {
    if (navItem.dropdown) {
      dropdownStates[navItem.content] = null
      nestedListStates[navItem.content] = false
    }
  }
  const [dropdowns, setDropdowns] = useState(dropdownStates)
  const [nestedStates, setNestedStates] = useState(nestedListStates)

  function dropdown(content, value) {
    setDropdowns({
      ...dropdowns,
      [content]: value,
    });
  }

  function showNestedList(content, value) {
    setNestedStates({
      ...nestedStates,
      [content]: value,
    });
  }
  function toggleNestedList(e, content) {
    e.stopPropagation();
    showNestedList(content, !nestedStates[content])
  }
  function closeNavDrawer() {
    setOpenDrawer(false);
  }
  function openNavDrawer() {
    setOpenDrawer(true);
  }

  return (
    <AppBar position="fixed" className="appBar" sx={navStyling}>
      <Toolbar variant="dense">
        <Button component={Link} to="/" mr={1} color="inherit" sx={{ flexShrink: 0 }}>
          <SvgIcon
            component={EcoMotionNavIcon}
            sx={{ height: "1.25em", width: "auto" }}
            inheritViewBox
          />
          <Typography
            variant="h6"
            ml={2}
            noWrap
            fontFamily="monospace"
            fontWeight={700}
            letterSpacing=".3rem"
            sx={{ display: { xs: 'none', sm: 'flex' } }}
          >
            ECOMOTION
          </Typography>
        </Button>
        <Box flexGrow={1} sx={{ display: { xs: 'none', md: 'flex' } }}>
          {navItems.map((navItem, i) =>
            <Fragment key={i}>
              <Button color="inherit" 
                {...navItem.props} 
                {...(navItem.dropdown) ? {
                  id: navItem.content,
                  onClick: (e) => {dropdown(navItem.content, e.currentTarget); navItem.onClick?.();},
                  endIcon: dropdowns[navItem.content] ? <ExpandLess /> : <ExpandMore />,
                  'aria-controls': dropdowns[navItem.content] ? navItem.content + '-dropdown' : undefined,
                  'aria-haspopup': true,
                  'aria-expanded': dropdowns[navItem.content] ? 'true' : undefined
                }: {onClick: navItem.onClick}}
              >
                {navItem.content}
              </Button>
              {navItem.dropdown && (
                <Menu
                  sx={{ display: { xs: 'none', md: 'block' } }}
                  id={navItem.content + "-dropdown"}
                  anchorEl={dropdowns[navItem.content]}
                  open={Boolean(dropdowns[navItem.content])}
                  onClose={() => dropdown(navItem.content, null)}
                  MenuListProps={{
                    'aria-labelledby': navItem.content,
                  }}
                  slotProps={{ paper: { sx: navStyling } }}
                >
                  {navItem.dropdown.items.map((item, i) =>
                    <MenuItem
                      key={i}
                      {...item.props}
                      onClick={() => {dropdown(navItem.content, null); item.onClick?.();}}
                    >
                      {item.content}
                    </MenuItem>
                  )}
                </Menu>
              )}
            </Fragment>
          )}
        </Box>
        <Box flexGrow={1} justifyContent="end" whiteSpace="nowrap" display="flex">
          <Search Icon={SearchIcon} placeholder="Search" />
          <AccountStatus navStyling={navStyling} />
          <Tooltip title="Open navigation drawer">
            <IconButton
              sx={{ display: { md: 'none' } }}
              size="large"
              onClick={openNavDrawer}
              color="inherit"
              edge="end"
            >
              <MenuIcon />
            </IconButton>
          </Tooltip>
          <SwipeableDrawer
            anchor='right'
            variant="temporary"
            open={Boolean(openDrawer)}
            onClick={closeNavDrawer}
            onClose={closeNavDrawer}
            onOpen={openNavDrawer}
            ModalProps={{
              keepMounted: true, // Better open performance on mobile.
            }}
            sx={{ display: { md: 'none' } }}
            PaperProps={{ sx: { ...navStyling, boxSizing: 'border-box' } }}
          >
            <DrawerHeader>
              <IconButton onClick={closeNavDrawer} color="inherit">
                <ChevronRightIcon />
              </IconButton>
            </DrawerHeader>
            <Divider sx={{ backgroundColor: navStyling.color, opacity: 0.5 }} />
            <List disablePadding>
              {navItems.map((navItem, i) =>
                <Fragment key={i}>
                  <ListItemButton
                    onClick={navItem.dropdown 
                      ? (e) => { toggleNestedList(e, navItem.content); navItem.onClick?.(); } 
                      : navItem.onClick}
                    {...navItem.props}
                  >
                    <ListItemText primary={navItem.content} />
                    {navItem.dropdown && (nestedStates[navItem.content] ? <ExpandLess /> : <ExpandMore />)}
                  </ListItemButton>
                  {navItem.dropdown?.items && (
                    <Collapse in={Boolean(nestedStates[navItem.content])} timeout="auto">
                      <List disablePadding>
                        {navItem.dropdown.items.map((item, i) =>
                          <ListItemButton sx={{ pl: 4 }} onClick={item.onClick} {...item.props} key={i}>
                            <ListItemText primary={item.content} />
                          </ListItemButton>
                        )}
                      </List>
                    </Collapse>
                  )}
                </Fragment>
              )}
            </List>
          </SwipeableDrawer>
        </Box>
      </Toolbar>
    </AppBar>
  );

}
