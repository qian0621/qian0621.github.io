// fixed
// checked case

import { useState, useEffect } from 'react';
import http from '../http';
//components
import { CardContent, CardHeader, CardMedia, CardActions, IconButton, Button, Stack, Box, Typography, Skeleton } from "@mui/material";
import BatteryGauge from './BatteryGauge';
//leaflet
import { useMap } from 'react-leaflet/hooks';
//icons
import CloseIcon from '@mui/icons-material/Close';
import FavoriteIcon from '@mui/icons-material/Favorite';
import LockIcon from '@mui/icons-material/Lock';
//styles
import "../styles/ChargingStationPopup.css";

export default function ChargingStationCardContent({id}) {
    const [chargingstation, setChargingStation] = useState(null);
    const map = useMap()
    function getChargingStation() {
        http.get('/chargingstation/' + id).then((res) => {
            setChargingStation(res.data);
        });
    };
    useEffect(() => {
        getChargingStation();
    }, []);

    function favourite() {
        //use context to access user
        console.log(chargingstation.id);
    }
    function closePopup() {
        map.closePopup();
    }

    return (
        <>
            <CardHeader
                avatar={
                    <IconButton aria-label="Close" onClick={closePopup}>
                        <CloseIcon/>
                    </IconButton>
                }
                title={"ID: " + id }
                subheader={ chargingstation?.ChargingStationModel.name ?? 
                    <Skeleton width="40%"/>
                }
                action={
                    <IconButton aria-label="Favorite" onClick={favourite}>
                        <FavoriteIcon/>
                    </IconButton>
                }
                sx={{p: 1}}
            />
            { chargingstation?.ChargingStationModel.image_file && (
                <CardMedia
                    className="model-card-media"
                    component="img"
                    src={`${import.meta.env.VITE_FILE_BASE_URL}${chargingstation.ChargingStationModel.image_file}`} 
                    alt="Charging Station Model"
                />
            )}
            <CardContent sx={{ px: 2, py: 0}}>
                <Stack
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                >
                    <Box>
                        <Typography variant="overline" display="block">Est Range</Typography>
                        <Typography variant="body1" fontSize="1.2rem">{(chargingstation)
                            ? Math.round(chargingstation.battery / chargingstation.ChargingStationModel.battery_per_km) + " km"
                            : <Skeleton />
                        }</Typography>
                    </Box>
                    {(chargingstation?.battery) 
                        ? <BatteryGauge level={chargingstation.battery} charging={chargingstation.charging} fontSize="1.4em"/>
                        : <Skeleton variant="circular" width="6.1em" height="2.94em"/>
                    }
                </Stack>
                <Typography variant="h6">{
                    (chargingstation) ? `$ ${chargingstation.ChargingStationModel.price_rate} / 30 min` : <Skeleton/>
                }</Typography>
            </CardContent>
            <CardActions disableSpacing sx={{display: "block"}}>
                <Button variant="contained" startIcon={<LockIcon />} fullWidth>
                    Use to Charge 
                </Button>
                <Button variant="text" size="small" href="/submitreport">Report Damages</Button>
            </CardActions>
        </>
    );
}
