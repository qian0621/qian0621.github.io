import { useState, useEffect, useRef, useContext } from 'react';
import UserContext from '../contexts/UserContext';
import http from '../http';
import { useLocation, useNavigate } from 'react-router-dom';
//leaflet
import { Popup, Pane } from 'react-leaflet';    //Marker, 
import CustMarker from './CustMarker';
import { Icon } from 'leaflet';
// import useFlyToOpenPopup from '../hooks/useFlyToOpenPopup';
import { Card } from "@mui/material";
import BikeCardContent from './BikeCardContent';

const bikeIcon = new Icon({
    iconUrl: "/bikeMarker.svg",
    iconSize: [24,36], // size of the icon
    iconAnchor:   [12, 36], // point of the icon which will correspond to marker's location
    popupAnchor:  [0, -6], // point from which the popup should open relative to the iconAnchor
    className: 'bike-marker-icon'
})


const bikePaneDefaultZindex = 600;

export default function BikeMarkers() {
    const { user } = useContext(UserContext);
    var locationRelUrl = '/bike/locations'
    if (!(user?.role === 'admin')) {
        locationRelUrl += '?' + new URLSearchParams({status: 'Available', battery: ''});
    }
    const [bikes, setBikes] = useState([]);
    // const targetBike = useFlyToOpenPopup();
    function getBikes() {
        // console.log(locationRelUrl);
        http.get(locationRelUrl).then(({data}) => {
            setBikes(data);
        });
    };
    useEffect(() => {
        getBikes();
    }, []);

    const { hash } = useLocation();
    const navigate = useNavigate();

    const openPopups = useRef([]);
    function handlePopupOpen(e, id) {
        // navigate("/" + newFragment);
        openPopups.current.push(e.popup.options.pane);
        e.popup.getPane().style.zIndex = bikePaneDefaultZindex + openPopups.current.length;
        const newFragment = '#bike' + id;
        //hash will change to newFragment even though url dosent
        // console.log(location.hash, newFragment); 
        if (location.hash !== newFragment) {
            history.pushState(null, null, newFragment);
        }
    }
    function handlePopupClose(e) {
        // navigate("/");  //todo: make sure this happends before popupopen
        // console.log("closing", e);
        history.pushState(null, null, "#"); //wont remove targetBike ref
        // location.hash = '';
        openPopups.current.splice(openPopups.current.indexOf(e.popup.options.pane), 1);
        e.popup.getPane().style.zIndex = bikePaneDefaultZindex;
    }

    return bikes.map((bike) => 
        <Pane className='bike-pane' key={bike.id} name={`bike${bike.id}Pane`} style={{ zIndex: bikePaneDefaultZindex }}>
            <CustMarker
                id={"bike" + bike.id} title={"Bike "+bike.id}
                position={bike.location.coordinates.slice().reverse()} icon={bikeIcon}
                isOpen={hash === "#bike" + bike.id}
                // ref={(hash === "#bike" + bike.id) ? targetBike : undefined}
                eventHandlers={{
                    // add: (e) => {IDtoPopUp.current.set("bike" + bike.id, e.sourceTarget);},
                    popupopen: (e) => (handlePopupOpen(e, bike.id)),
                    popupclose: handlePopupClose
                }}
            >
                <Card variant="outlined" className='bike-popup'
                    component={Popup} closeButton={false} interactive bubblingMouseEvents={false}
                >
                    <BikeCardContent id={bike.id}/>
                </Card>
            </CustMarker>
        </Pane>
    );
}
