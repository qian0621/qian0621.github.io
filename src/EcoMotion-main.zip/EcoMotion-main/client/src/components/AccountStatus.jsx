import {useState, useContext} from 'react'
import {Button, Menu, MenuItem, Typography} from '@mui/material'
import { Link } from 'react-router-dom';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import UserContext from '../contexts/UserContext'
 
export default function AccountStatus({navStyling}) {
    const [userAnchorEl, setUserAnchorEl] = useState(null);
    const {user, setUser} = useContext(UserContext);
    

    const logout = () => {
        localStorage.clear();
        setUser(null);
        window.location = "/";
    };

    function closeDropdown() {
        setUserAnchorEl(null)
    }

    return user ? (
        <>
            <Button 
                color="inherit"
                id="user-account"
                onClick={(e) => setUserAnchorEl(e.currentTarget)}
                endIcon={userAnchorEl ? <ExpandLess /> : <ExpandMore />}
                aria-controls={userAnchorEl ? "user-dropdown" : undefined}
                aria-haspopup
                aria-expanded={Boolean(userAnchorEl)} 
            >{user.name} </Button>
            <Menu
                id="user-dropdown"
                anchorEl={userAnchorEl}
                open={Boolean(userAnchorEl)}
                onClose={closeDropdown}
                MenuListProps={{
                    'aria-labelledby': "user-account",
                }}
                slotProps={{ paper: { sx: navStyling } }}
            >
                <MenuItem
                    component={Link}
                    to="/profile"
                    onClick={closeDropdown}
                    >
                    <Typography textAlign="center">My Profile</Typography>
                </MenuItem>
                <MenuItem
                    onClick={() => {logout(); closeDropdown();}}
                    >
                    <Typography textAlign="center">Logout</Typography>
                </MenuItem>
            </Menu>
        </>
    ): (
        <>
            <Button component={Link} to="/register" color="inherit">
            Register
            </Button>
            <Button component={Link} to="/login" color="inherit">
            Login
            </Button>
        </>
    )
}
