import { 
  MapContainer, 
  TileLayer,
  CircleMarker,
} from 'react-leaflet';
import { useMapEvents } from 'react-leaflet/hooks';
import { useState, useRef } from 'react';
import 'leaflet/dist/leaflet.css';
import BikeMarkers from './BikeMarkers';

export default function Map({center}) {
  const [currLoc, setCurrLoc] = useState(null);
  const focused = useRef(false);
  function CenterCurrLoc() {
    //using useMapEvents leaflet hook (Note that, if your page doesn't use HTTPS, this method will fail in modern browsers)
    const map = useMapEvents({
      // load: () => {
      //   map.locate({watch: true});
      // },
      // locationfound: (e) => {
      //   setCurrLoc([e.latlng.lat, e.latlng.lng]);
      //   console.log(currLoc)
      //   if (center === undefined && !focused) map.flyTo(e.latlng, map.getMaxZoom());
      // },
      focus: () => {
        focused.current = true;
      }
    })

    // using navigator.geolocation
    async function successCallback(position) {
      const currentLocation = [position.coords.latitude, position.coords.longitude];  //temp variable to avoid stale closure
      setCurrLoc(currentLocation);
      console.log(currentLocation);
      if (!focused.current && center === undefined && !location.hash) {
        await map.flyTo(currentLocation, map.getMaxZoom())
      };
    };
    
    function errorCallback(error) {
      console.log(error);
    };
    if (navigator.geolocation) {
      const watchID = navigator.geolocation.watchPosition(successCallback, errorCallback);
    }

    return null;
  }

  return (
    <div className="map">
      <MapContainer center={center ?? currLoc ?? [1.3521, 103.8198]} zoom={(center || currLoc)? 17 : 12} scrollWheelZoom maxBounds={[[1.1587, 103.596], [1.4835, 104.092]]}>
        <TileLayer
          attribution='<img src="https://www.onemap.gov.sg/web-assets/images/logo/om_logo.png" style="height:20px;width:20px;"/>&nbsp;<a href="https://www.onemap.gov.sg/" target="_blank" rel="noopener noreferrer">OneMap</a>&nbsp;&copy;&nbsp;contributors&nbsp;&#124;&nbsp;<a href="https://www.sla.gov.sg/" target="_blank" rel="noopener noreferrer">Singapore Land Authority</a>'
          url='https://www.onemap.gov.sg/maps/tiles/Default_HD/{z}/{x}/{y}.png'
          detectRetina={true}
          minZoom={12}
        />
        <CenterCurrLoc/>
        {currLoc && <CircleMarker center={currLoc} radius={7} fill/>}
        <BikeMarkers/>
      </MapContainer>
    </div>
  )
}