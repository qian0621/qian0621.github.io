import { useState } from "react";
import { Card, CardContent, CardHeader, CardMedia, CardActions, IconButton, TextField, Button, InputAdornment, Box } from "@mui/material";
import { Done, Edit, EditOff, Cancel, Delete } from "@mui/icons-material";
import "../styles/BikeModelCard.css";
import { toast } from 'react-toastify';
import http from '../http';
import { useFormik } from 'formik';
import * as yup from 'yup';

export const modeltoElementID = (name) => encodeURI(name)

export function smoothScrollingTo(elementID) {
    document.getElementById(elementID)?.scrollIntoView(
        { behavior: "smooth", block: "nearest" }
    );
}

export function controlScrolltoTarget(elementID) {
    const urlFragment = "#" + elementID;
    if (location.hash !== "" && location.hash != urlFragment) {
        history.pushState(null, null, urlFragment);
    }
    smoothScrollingTo(elementID)
}

export default function BikeModelCard({ bikeModel, form, AddButton, onEdit, onSubmit, onClose, onDelete }) {
    if (!bikeModel) {
        if (!form) throw new Error("form is required for new bike models");
        if (!AddButton) throw new Error("add is required for new bike models");
        if (onEdit) throw new Error("onEdit is only valid for existing bike models");
        if (onDelete) throw new Error("onDelete is only valid for existing bike models");
    }
    if (!form) {
        if (onSubmit) throw new Error("onSubmit is only valid for forms");
        if (onClose) throw new Error("onClose is only valid for forms");
    }
    
    const [imageFile, setImageFile] = useState(bikeModel?.image_file);
    
    function handleDelete() {
        if (bikeModel.total_bikes != 0) throw new Error("Cannot delete bike model with bikes");
        if (confirm(`Are you sure you want to delete ${bikeModel.name}?`)) {
            http.delete("/bikeModel/" + bikeModel.id)
                .then((res) => {
                    toast.success(res.data.message);
                    onDelete();
                }).catch(function (error) {
                    console.log(error.response);
                    toast.error(error.response.data.message);
                });
        }
    }
    
    function onFileChange(e) {
        let file = e.target.files[0];
        if (file) {
            if (file.size > 1024 * 1024) {
                toast.error('Maximum file size is 1MB');
                //ToastConatiner set up in App.jsx
                return;
            }

            let formData = new FormData();
            formData.append('file', file);
            
            http.post('/file/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }).then((res) => {
                setImageFile(res.data.filename);
            }).catch(function (error) {
                console.log(error.response);
            });
        }
    };

    const formik = useFormik({
        initialValues: {
            name: bikeModel?.name ?? "",
            battery_per_km: bikeModel?.battery_per_km ?? "",
            price_rate: bikeModel?.price_rate ?? ""
        },
        validationSchema: yup.object({
            name: yup.string().trim()
                .max(100, 'Name must be at most 100 characters')
                .required('Name is required'),
            battery_per_km: yup.number()
                .min(0, 'Battery must be positive')
                .max(100, 'Maximum battery level is 100%')
                .required('Battery%/km is required'),
            price_rate: yup.number()
                .max(9.99, "Let's not scam people")
                .required("Price must be set")
        }),
        onSubmit: (data) => {
            console.log(data)
            if (imageFile) {
                data.image_file = imageFile;
            }
            data.name = data.name.trim();
            var url = "/bikeModel"
            var method;
            var targetID
            if (bikeModel) {
                method="put";
                targetID = bikeModel.name;
                url += "/" + bikeModel.id;
            } else {
                method="post";
            }
            http[method](url, data)
                .then((res) => {
                    console.log(res.data);
                    toast.success(res.data.message ?? res.data.name + " was added successfully");
                    onSubmit();
                    controlScrolltoTarget(modeltoElementID(targetID ?? res.data.name));
                }).catch(function (error) {
                    console.log(error.response);
                    toast.error(error.response.data.message);
                });
        }
    });

    
    return (
        <Card
            id={modeltoElementID(bikeModel?.name ?? "new")}
            {...(form) ? {component: "form", onSubmit: formik.handleSubmit} : {} } 
            sx={{ width: 475 }}
        >
            <CardHeader
                {...(form) 
                    ? {avatar: (
                        <IconButton aria-label="Cancel" type="button" onClick={onClose} color="error" size="large">
                            {(bikeModel) ? <EditOff/>: <Cancel/>}
                        </IconButton>
                    )} : {} }
                title={ (form) 
                    ? (
                        <Box display="flex" alignItems="center" justifyContent="space-evenly">
                            <TextField 
                                label="Name" name="name" required 
                                size="small" sx={{minWidth: "15ch"}}
                                value={formik.values.name}
                                onChange={formik.handleChange}
                                error={formik.touched.name && Boolean(formik.errors.name)}
                                helperText={formik.touched.name && formik.errors.name}
                            />
                            <Button variant="outlined" component="label" sx={{whiteSpace: "nowrap"}}>
                                Upload Image
                                <input hidden accept="image/*" multiple type="file"
                                    onChange={onFileChange} />
                            </Button>
                        </Box>
                    ) : bikeModel.name
                }
                action={(AddButton)? <AddButton type="submit"/> :
                    <IconButton
                        aria-label={ (form)? "Done": "Edit" } 
                        {...(form)? {type: "submit", color: "success"} : {type: "button", onClick: onEdit, color: "warning"}}
                    >
                        {(form)?<Done/>: <Edit />}
                    </IconButton>
                }
            />
            <CardMedia className="model-card-media">
            { imageFile ? (
                    <img
                        src={`${import.meta.env.VITE_FILE_BASE_URL}${imageFile}`} 
                        alt={bikeModel?.name ?? "Uploaded bike image"}
                        loading="lazy"
                    />
                ) : (
                    <div className="img-placeholder">
                        No image uploaded
                    </div>
                )
            }
            </CardMedia>
            <CardContent>
                <TextField
                    InputProps={{
                        startAdornment: <InputAdornment position="start">Battery: </InputAdornment>,
                        endAdornment: <InputAdornment position="end">% / km</InputAdornment>,
                    }}
                    variant="filled" size="small" hiddenLabel fullWidth value={formik.values.battery_per_km}
                    { ...(form) 
                        ? {
                            name: "battery_per_km", 
                            required: true, 
                            type: "number", 
                            onChange: formik.handleChange,
                            error: formik.touched.battery_per_km && Boolean(formik.errors.battery_per_km),
                            helperText: formik.touched.battery_per_km && formik.errors.battery_per_km
                        }: {inputProps: {readOnly: true} }
                    }
                />
                <TextField
                    InputProps={{
                        startAdornment: <InputAdornment position="start">Price: $</InputAdornment>,
                        endAdornment: <InputAdornment position="end">/ 30min</InputAdornment>,
                    }}
                    variant="filled" size="small" hiddenLabel fullWidth value={formik.values.price_rate}
                    { ...(form) 
                        ? {
                            name: "price_rate", 
                            required: true, 
                            type: "number", 
                            onChange: formik.handleChange,
                            error: formik.touched.price_rate && Boolean(formik.errors.price_rate),
                            helperText: formik.touched.price_rate && formik.errors.price_rate
                        }: {inputProps: {readOnly: true} }
                    }
                />
            </CardContent>
            { bikeModel && (
                <CardActions disableSpacing>
                    {(bikeModel.total_bikes == 0) ? (
                        <Button variant="contained" color="error" onClick={handleDelete} startIcon={<Delete/>}>
                            Delete
                        </Button>
                    ) : (
                        <Button variant="text" color="info" href="/bikes">{bikeModel.total_bikes} bike(s) in use</Button>
                    )}
                </CardActions>
            )}
        </Card>
    )
}
