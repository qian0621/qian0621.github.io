import { Marker } from 'react-leaflet';
import { useRef, useEffect } from 'react';
import { useMap } from 'react-leaflet/hooks';

export default function CustMarker({isOpen, ...props}) {
    // console.log(isOpen, props)
    const map = useMap();
    const markerRef = useRef(null);
    useEffect(() => {
        if (isOpen) {
            const marker = markerRef.current;
            console.log(marker);
            map.flyTo(marker.getLatLng(), map.getMaxZoom())
            map.once('zoomend', () => marker.openPopup());
        }
    }, [isOpen]);
    return <Marker ref={markerRef} {...props} />;
}
