// fixed

import { 
    Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, 
    Button, Select, MenuItem, InputLabel, FormControl, FormHelperText
} from '@mui/material';
import { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import http from '../http';
import { useFormik } from 'formik';
import * as yup from 'yup';

const statuses = ["available", "unavailable", "maintenance"];
// const statusRegex = new RegExp("^(" + statuses.join("|") + ")$");
//fake data
const chargingstationIoTdata = { 
    battery: {percent: 10, charging: true}, 
    location: {latitude: 1.37, longitude: 103.84 }
};

export function toTitleCase(str) {
    return str.toLowerCase().replace(/(^|\s)\w/g, (match) => match.toUpperCase());
}

export function getChargingStationModels(successCallback) {
    http.get('/chargingstationModel').then(successCallback);
}

export default function ChargingStationForm(props) {
    const { open, onClose, onSubmit, AddButton } = props;
    const [chargingstationModels, setChargingStationModels] = useState([]);

    useEffect(() => {
        getChargingStationModels((res) => setChargingStationModels(res.data));
    }, []);

    const formik = useFormik({
        initialValues: {
            status: "",
            model_id: "",
        },
        validationSchema: yup.object({
            status: yup.string().trim().oneOf(statuses).required(),
            model_id: yup.string().required()
        }),
        onSubmit: (data) => {
            data.battery = chargingstationIoTdata.battery.percent;
            data.charging = chargingstationIoTdata.battery.charging;
            data.location = [chargingstationIoTdata.location.latitude, chargingstationIoTdata.location.longitude];
            console.log(data)
            http.post('/chargingstation', data)
                .then((res) => {
                    console.log(res.data);
                    onSubmit();
                }).catch(function (error) {
                    console.log(error.response);
                    toast.error(error.response.data.message);
                });
            onClose();
        }
    });

    return (
        <Dialog component="form" open={open} onClose={onClose} onSubmit={formik.handleSubmit} PaperProps={{sx: {minWidth: 400}}}>
            <DialogTitle>New Charging Station</DialogTitle>
            <DialogContent>
                <DialogContentText>
                    Battery: {chargingstationIoTdata.battery.percent}%{chargingstationIoTdata.battery.charging && " , Charging"}<br/>
                    Latitude: {chargingstationIoTdata.location.latitude}<br/>
                    Longitude: {chargingstationIoTdata.location.longitude}<br/>
                </DialogContentText>
                <FormControl component="div" fullWidth variant="standard">
                    <InputLabel id="status-label">Status</InputLabel>
                    <Select
                        labelId="status-label"
                        value={formik.values.status}
                        onChange={formik.handleChange}
                        error={formik.touched.status && Boolean(formik.errors.status)}
                        name="status"
                        required
                        label="Status"
                    >
                        {/* <MenuItem selected disabled value="">
                            Select Charging Station Model
                        </MenuItem> */}
                        {statuses.map((status) => <MenuItem key={status} value={status}>{toTitleCase(status)}</MenuItem>)}
                    </Select>
                    <FormHelperText>{formik.touched.status && formik.errors.status}</FormHelperText>
                </FormControl>
                <FormControl component="div" fullWidth variant="standard">
                    <InputLabel id="model-label">Model</InputLabel>
                    <Select 
                        fullWidth
                        labelId="model-label"
                        value={formik.values.model_id}
                        onChange={formik.handleChange}
                        error={formik.touched.model_id && Boolean(formik.errors.model_id)}
                        name="model_id"
                        required
                        label="Model"
                    >
                        {/* <MenuItem selected disabled value="">
                            Select Charging Station Model
                        </MenuItem> */}
                        {chargingstationModels.map((chargingstationModel) => 
                            <MenuItem key={chargingstationModel.id} value={chargingstationModel.id}>{chargingstationModel.name}</MenuItem>
                        )}
                    </Select>
                    <FormHelperText>{formik.touched.model_id && formik.errors.model_id}</FormHelperText>
                </FormControl>
            </DialogContent>
            <DialogActions>
            <Button onClick={onClose} type="button">Cancel</Button>
            <AddButton type="submit"/>
            </DialogActions>
        </Dialog>
    )
}