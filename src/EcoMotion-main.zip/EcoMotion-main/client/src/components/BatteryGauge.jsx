import '../styles/BatteryGauge.css';
import BoltIcon from '@mui/icons-material/Bolt'

export default function Battery({level, lowBattery=20, charging, textProps, fontSize}) {
  var color;
  if ((level < lowBattery) && !charging) {
    color = 'red'
  } else {
    color = 'green'
  }
  return (
    <div className="battery" style={{fontSize: fontSize}}>
      <div className="battery-body">
          <div className="battery-fill">
            <div className="battery-level" style={{  backgroundColor: color, width: level+"%"}}/>
            <div className="battery-text">
                {charging && <BoltIcon className="charging-icon" titleAccess='charging' viewBox='6 2 12 20'/>}
                <h6 {...textProps}>
                {level}%
                </h6>
            </div>
          </div>
      </div>
      <div className="battery-tip"/>
    </div>
  );
}