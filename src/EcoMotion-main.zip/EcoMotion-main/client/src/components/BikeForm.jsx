import { 
    Dialog, DialogTitle, DialogContent, DialogContentText, DialogActions, 
    Button, Select, MenuItem, InputLabel, FormControl, FormHelperText
} from '@mui/material';
import { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import http from '../http';
import { useFormik } from 'formik';
import * as yup from 'yup';

const statuses = ["available", "unavailable", "maintenance"];
// const statusRegex = new RegExp("^(" + statuses.join("|") + ")$");
//fake data
function generateFakeTrackerData() {
    const batteryPercent = Math.floor(Math.random() * 100) + 1; // Random number between 1 and 100
    const isCharging = Math.random() < 0.5; // Random true/false value for charging status
  
    // Generate random latitude and longitude within the specified range
    const minLatitude = 1.1587;
    const maxLatitude = 1.4835;
    const minLongitude = 103.596;
    const maxLongitude = 104.092;
  
    const latitude = minLatitude + Math.random() * (maxLatitude - minLatitude);
    const longitude = minLongitude + Math.random() * (maxLongitude - minLongitude);
  
    const bikeIoTdata = {
      battery: { percent: batteryPercent, charging: isCharging },
      location: { latitude: latitude, longitude: longitude }
    };
  
    return bikeIoTdata;
}

const bikeIoTdata = generateFakeTrackerData();

export function toTitleCase(str) {
    return str.toLowerCase().replace(/(^|\s)\w/g, (match) => match.toUpperCase());
}

export function getBikeModels(successCallback) {
    http.get('/bikeModel').then(successCallback);
}

export default function BikeForm(props) {
    const { open, onClose, onSubmit, AddButton } = props;
    const [bikeModels, setBikeModels] = useState([]);

    useEffect(() => {
        getBikeModels((res) => setBikeModels(res.data));
    }, []);

    const formik = useFormik({
        initialValues: {
            status: "",
            model_id: "",
        },
        validationSchema: yup.object({
            status: yup.string().trim().oneOf(statuses).required(),
            model_id: yup.string().required()
        }),
        onSubmit: (data) => {
            data.battery = bikeIoTdata.battery.percent;
            data.charging = bikeIoTdata.battery.charging;
            data.location = [bikeIoTdata.location.latitude, bikeIoTdata.location.longitude];
            console.log(data)
            http.post('/bike', data)
                .then((res) => {
                    console.log(res.data);
                    onSubmit();
                }).catch(function (error) {
                    console.log(error.response);
                    toast.error(error.response.data.message);
                });
            onClose();
        }
    });

    return (
        <Dialog component="form" open={open} onClose={onClose} onSubmit={formik.handleSubmit} PaperProps={{sx: {minWidth: 400}}}>
            <DialogTitle>New Bike</DialogTitle>
            <DialogContent>
                <DialogContentText>
                    Battery: {bikeIoTdata.battery.percent}%{bikeIoTdata.battery.charging && " , Charging"}<br/>
                    Latitude: {bikeIoTdata.location.latitude}<br/>
                    Longitude: {bikeIoTdata.location.longitude}<br/>
                </DialogContentText>
                <FormControl component="div" fullWidth variant="standard">
                    <InputLabel id="status-label">Status</InputLabel>
                    <Select
                        labelId="status-label"
                        value={formik.values.status}
                        onChange={formik.handleChange}
                        error={formik.touched.status && Boolean(formik.errors.status)}
                        name="status"
                        required
                        label="Status"
                    >
                        {/* <MenuItem selected disabled value="">
                            Select Bike Model
                        </MenuItem> */}
                        {statuses.map((status) => <MenuItem key={status} value={status}>{toTitleCase(status)}</MenuItem>)}
                    </Select>
                    <FormHelperText>{formik.touched.status && formik.errors.status}</FormHelperText>
                </FormControl>
                <FormControl component="div" fullWidth variant="standard">
                    <InputLabel id="model-label">Model</InputLabel>
                    <Select 
                        fullWidth
                        labelId="model-label"
                        value={formik.values.model_id}
                        onChange={formik.handleChange}
                        error={formik.touched.model_id && Boolean(formik.errors.model_id)}
                        name="model_id"
                        required
                        label="Model"
                    >
                        {/* <MenuItem selected disabled value="">
                            Select Bike Model
                        </MenuItem> */}
                        {bikeModels.map((bikeModel) => 
                            <MenuItem key={bikeModel.id} value={bikeModel.id}>{bikeModel.name}</MenuItem>
                        )}
                    </Select>
                    <FormHelperText>{formik.touched.model_id && formik.errors.model_id}</FormHelperText>
                </FormControl>
            </DialogContent>
            <DialogActions>
            <Button onClick={onClose} type="button">Cancel</Button>
            <AddButton type="submit"/>
            </DialogActions>
        </Dialog>
    )
}
