const multer = require('multer');
const { nanoid } = require('nanoid');
const path = require('path');
const storage = multer.diskStorage({
    destination: (req, file, callback) => {
        callback(null, './public/uploads/');    //Set the destination to \public\uploads folder
    },
    filename: (req, file, callback) => {
        callback(null, nanoid(10) + path.extname(file.originalname));   //Replace the original file name to a new unique id
    }
});
const upload = multer({
    storage: storage,
    limits: { fileSize: 1024 * 1024 },  //1MB
}).single('file'); // file input name

module.exports = { upload };