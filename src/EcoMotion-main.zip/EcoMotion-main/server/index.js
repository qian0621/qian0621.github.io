"use strict";
const cors = require("cors");
const express = require("express");
const bodyParser = require("body-parser");
const db = require("./models");
const bcrypt = require("bcrypt");
const Sequelize = require("sequelize");
require("dotenv").config();
const stripe = require("stripe")(
  "sk_test_51NOvtFDZoqDdWCBfuJLSUykflqeaJa4vdw7vCQ3xhEZsy94NYbq7siMF1ivBKeBOpjjkiNzSXACD5mKguNaTBPbU008rc7LkHn"
);
const mysql = require("mysql2");
const urlsafeBase64 = require('urlsafe-base64');
require("dotenv").config();
// const { default: Invoice } = require('../client/src/pages1/invoice');

const app = express();
app.use(cors());
app.use(express.json());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static("public"));

// Simple Route
app.get("/", (req, res) => {
  res.send("Welcome to EcoMotion.");
});

// Routes
const userRoute = require("./routes/user");
app.use("/user", userRoute);
const fileRoute = require("./routes/file");
app.use("/file", fileRoute);
const bikeModelRoute = require("./routes/bikeModel");
app.use("/bikeModel", bikeModelRoute);
const bikeRoute = require("./routes/bike");
app.use("/bike", bikeRoute);
const reportRoute = require("./routes/reports");
app.use("/reports", reportRoute);
const customerfavouriterouteRoute = require("./routes/customerfavouriteroutes");
app.use("/customerfavouriteroutes", customerfavouriterouteRoute);
const chargingstationModelRoute = require("./routes/chargingstationModel");
app.use("/chargingstationModel", chargingstationModelRoute);
const chargingstationRoute = require("./routes/chargingstation");
app.use("/chargingstation", chargingstationRoute);

const { Invoice } = require("./models");
const { Card } = require("./models");
const { TimeDifference } = require("./models");
const { User } = require("./models");
const { TopUp } = require("./models");
db.sequelize.sync({ alter: true }).then(() => {
  const port = process.env.APP_PORT;
  app.listen(port, () => {
    console.log(`⚡ Server running on http://localhost:${port}`);
  });
});

app.get("/api/get/allcard", (req, res) => {
  Card.findAll()
    .then((cards) => {
      res.send(cards);
    })
    .catch((error) => {
      console.error("Error retrieving cards:", error);
    });
});


app.get("/api/get/card/:id", (req, res) => {
  const { id } = req.params;
  Card.findAll({
    where: {
      user_id: id,
    },
  })
    .then((cards) => {
      let data=[]
      for (let index = 0; index < cards.length; index++) {
        const element = cards[index];
        let card_number=urlsafeBase64.decode(element.card_number).toString('utf-8');
        element.card_number=card_number
        data.push(element)
        console.log(element)
      }
      res.send(data);
    })
    .catch((error) => {
      console.error("Error retrieving cards:", error);
    });
});

app.put("/api/get/onecard", (req, res) => {
  const id = req.body.id;
  Card.findAll({
    where: {
      id: id,
    },
  })
    .then((cards) => {
      res.send(cards);
    })
    .catch((error) => {
      console.error("Error retrieving cards:", error);
    });
});

app.post("/api/post/card", async (req, res) => {
  const data = req.body;
  if (
    data.cardNumber.length === 16 &&
    data.cardHolderName &&
    data.cardMonth.length === 2 &&
    data.cardYear.length === 2 &&
    data.CVC.length === 3
  ) {
    try {
      let user = await User.findByPk(data.user_id);

      if (!user) {
        console.log("User not found.");
        res.send("fail");
        return;
      }

      const card = Card.build({
        card_number:urlsafeBase64.encode(Buffer.from( data.cardNumber)),
        cardholder_name: data.cardHolderName,
        exp_month: data.cardMonth,
        exp_year: data.cardYear,
        cvv: data.CVC,
        user_id: user.id,
      });
   

      card
        .save()
        .then((savedCard) => {
          console.log("Card saved:", savedCard);
          res.send("success");
        })
        .catch((error) => {
          console.error("Error saving card:", error);
          res.send("fail");
        });
    } catch (error) {
      console.error("Error finding user:","this error");
      res.send("fail");
    }
  } else {
    console.log("Data inserted unsuccessfully:");
    res.send("fail");
  }
});

// Delete card data
app.delete("/api/delete/card/:id", async (req, res) => {
  const { id } = req.params;
  Card.destroy({
    where: { id: id },
  })
    .then((deletedCount) => {
      if (deletedCount > 0) {
        console.log("Card deleted successfully.");
        res.send("Delete");
      } else {
        console.log("Card not found or already deleted.");
      }
    })
    .catch((error) => {
      console.error("Error deleting card:", error);
    });
});

// Update card data
app.put("/api/update/card/:id", async (req, res) => {
  const { id } = req.params;
  const { cardNumber, cardHolderName, cardMonth, cardYear, CVC, balance } =
    req.body;
  if (
    cardHolderName &&
    cardMonth.length === 2 &&
    cardYear.length === 2 &&
    CVC.length === 3
  ) {
    const updatedData = {
      card_number: cardNumber,
      cardholder_name: cardHolderName,
      exp_month: cardMonth,
      exp_year: cardYear,
      cvv: CVC,
      balance,
    };

    Card.update(updatedData, {
      where: { id: id },
    })
      .then((updatedCount) => {
        if (updatedCount > 0) {
          console.log("Card updated successfully.");
          res.send("success");
        } else {
          console.log("lkjdsflkja")
          console.log("Card not found or already up to date.");
        }
      })
      .catch((error) => {
        console.error("Error updating card:", error);
      });
  } else {
    console.log("Invalid card details");
    res.status(400).send("Invalid card details");
  }
});


app.get("/api/get/balance/:id", (req, res) => {
  const { id } = req.params;
  User.findOne({
    where: { id: id },
  })
  .then((user) => {
      res.send(user);
    })
    .catch((error) => {
      console.error("Error retrieving cards:", error);
    });
});

//Top up
app.put("/api/topup/card/:id", async(req, res) => {
  const { id } = req.params;
  let { balance } = req.body;
  let paymentIntent =null;
  if(balance<50){
    paymentIntent = await stripe.paymentIntents.create({
      amount:50,
      currency: "usd",
    });
  }else{
    paymentIntent = await stripe.paymentIntents.create({
      amount:balance,
      currency: "usd",
    });
  }
   
  Card.findOne({where:{id:id}}).then((card)=>{
    const topup = TopUp.build({
      stripe_client_secret:paymentIntent.client_secret,
      amount:balance,
      card_id: card.id,
    });
    topup
        .save().then((topup) => {
          User.findOne({
              where: { id: card.user_id },
            }).then((user) => {
              if (user) {
                let newBalance = 0;
                if (user.balance !== null) {
                      newBalance = parseInt(balance) + parseInt(user.balance);
                    } else {
                      newBalance = parseInt(balance);
                    }
                    const updatedData = {
                      balance: newBalance,
                    };
                    User.update(updatedData, {
                        where: { id: card.user_id},
                      })
                        .then((updatedCount) => { 
                          res.send(updatedData);
                        })
                        .catch((error) => {
                          console.error("Error updating card:", error);
                        });
              }
            }).catch((error) => {
          console.error("Error saving topup:", error);
          res.send("fail");
        }); 
      }).catch((error) => {
        res.send("fail");
      });
});
});


//Topup List
app.get("/api/topup/list",(req,res)=>{
  
  TopUp.findAll()
  .then(async(topups) => {
    console.log(topups)
    var topuplist=[]
    for (let index = 0; index < topups.length; index++) {
      var data={amount:topups[index].amount,stripe_client_secret:topups[index].stripe_client_secret,name:''}
      const element = topups[index];
      await Card.findOne({where: { id: element.card_id }}).then((card)=>{
        data['name']=card.cardholder_name
        
      })    
      topuplist.push(data) 
    } 
    res.send(topuplist);
  })
  .catch((error) => {
    console.error("Error retrieving cards:", error);
  });
  
})


// get one customer invoices
app.get("/api/get/:user_id", (req, res) => {
  const { user_id } = req.params;

  Invoice.findAll({
    where: { user_id: user_id },
    order: [["date", "DESC"]],
  })
    .then((invoices) => {
      if (invoices.length > 0) {
        res.send(invoices);
      } else {
        res.send("fail");
      }
    })
    .catch((error) => {
      console.error("Error selecting invoice:", error);
      res.status(500).send("Error selecting invoice.");
    });
});

// get all invoices
app.get("/api/allinvoice", (req, res) => {
  Invoice.findAll({
    order: [["date", "DESC"]],
  })
    .then((invoices) => {
      if (invoices.length > 0) {
        res.send(invoices);
      } else {
        res.send(123);
      }
    })
    .catch((error) => {
      console.error("Error selecting invoice:", error);
      res.status(500).send("Error selecting invoice.");
    });
});

//scan qr
app.post("/qr-scan/:id", (req, res) => {
  const { id } = req.params;
  TimeDifference.findOne({
    where: { user_id: id, finish: false },
  })
    .then(async (data) => {
      if (data) {
        var diff = (new Date() - data.start_time) / (1000 * 3600);
        TimeDifference.destroy({
          where: { id: data.id },
        });
        var amount = 0;
        if (diff < 1) { //diff is hour,1=1hour,2=2hour
          amount = 50;
        } else if (diff > 1 && diff < 2) {
          amount = 100;
        } else if (diff > 2 && diff < 3) {
          amount = 150;
        } else {
          amount = 200;
        }
        const invoice = Invoice.build({
          date: new Date(),
          cost: amount,
          user_id: id,
        });
        User.findOne({
          where: { id: id },
        })
          .then((user) => {
            if (user.balance !== null && user.balance > parseInt(amount)) {
              let newBalance = user.balance - amount;
              const updatedData = {
                balance: newBalance,
              };
             
              User.update(updatedData, {
                where: { id: user.id },
              })
                .then((updatedCount) => {
                  if (updatedCount > 0) {
                    invoice
                      .save()
                      .then((savedInvoice) => {
                        res.send(savedInvoice);
                      })
                      .catch((error) => {
                        console.error("Error saving card:", error);
                      });
                  } else {
                    res.send("fail");
                  }
                })
                .catch((error) => {
                  console.error(error);
                  res.send("fail");
                });
            } else {
              res.send("fail");
            }
          })
          .catch((error) => {
            console.error(error);
            res.send("fail");
          });
      } else {
        const time_difference = TimeDifference.build({
          user_id: id,
          start_time: new Date(),
          finish: false,
        });
        time_difference
          .save()
          .then((data) => {
            res.send(data);
          })
          .catch((error) => {
            console.error(error);
          });
      }
    })
    .catch((error) => {
      console.error(error);
      res.send("fail");
    });
});

// invoice add
app.post("/create-payment-intent", async (req, res) => {
  const { amount } = req.body;
  const user_id = 1;
  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency: "usd",
  });
  const invoice = Invoice.build({
    date: new Date(),
    cost: amount,
    user_id: 1,
    stripe_client_secret: paymentIntent.client_secret,
  });
  Card.findOne({
    where: { user_id: user_id },
  })
    .then((card) => {
      if (card.balance !== null && card.balance > parseInt(amount)) {
        let newBalance = card.balance - amount;
        const updatedData = {
          balance: newBalance,
        };
        Card.update(updatedData, {
          where: { id: card.id },
        })
          .then((updatedCount) => {
            if (updatedCount > 0) {
              invoice
                .save()
                .then((savedInvoice) => {
                  res.send(savedInvoice);
                })
                .catch((error) => {
                  console.error("Error saving card:", error);
                });
            } else {
              res.send("fail");
            }
          })
          .catch((error) => {
            console.error(error);
            res.send("fail");
          });
      } else {
        res.send("fail");
      }
    })
    .catch((error) => {
      console.error(error);
      res.send("fail");
    });
});