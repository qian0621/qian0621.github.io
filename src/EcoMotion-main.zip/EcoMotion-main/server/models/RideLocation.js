module.exports = (sequelize, DataTypes) => {
    const RideLocation = sequelize.define("RideLocation", {
        location: {
            type: DataTypes.GEOMETRY('POINT', 4326),
            allowNull: false
        }
    }, {
        timestamps: true,
        updatedAt: false,
    });

    RideLocation.associate = (models) => {
        RideLocation.belongsTo(models.Ride, {
            foreignKey: "ride_id",
            allowNull: false,
            onDelete: "CASCADE",
        });
    };

    return RideLocation;
}