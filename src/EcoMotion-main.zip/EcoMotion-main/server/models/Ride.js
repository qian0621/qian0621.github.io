module.exports = (sequelize, DataTypes) => {
    const Ride = sequelize.define("Ride", {}, {timestamps: false});

    Ride.associate = (models) => {
        Ride.hasMany(models.RideLocation);
    };

    return Ride;
}