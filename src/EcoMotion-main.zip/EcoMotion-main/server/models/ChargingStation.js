module.exports = (sequelize, DataTypes) => {
    const ChargingStation = sequelize.define("ChargingStation", {
        status: {
            type: DataTypes.ENUM,
            values: ["available", "unavailable", "retired", "maintenance"],
            allowNull: false
        },
        battery: {
            type: DataTypes.INTEGER.UNSIGNED
        }, 
        charging: {
            type: DataTypes.BOOLEAN
        },
        location: {
            type: DataTypes.GEOMETRY('POINT', 4326),
        }
    });

    ChargingStation.associate = (models) => {
        ChargingStation.belongsTo(models.ChargingStationModel, {
            foreignKey: "model_id",
            allowNull: false,
            onDelete: "RESTRICT"
        });
    };

    return ChargingStation;
}
