module.exports = (sequelize, DataTypes) => {
    const ChargingStationModel = sequelize.define("ChargingStationModel", {
        name: {
            type: DataTypes.STRING(100),
            allowNull: false,
            unique: true
        },
        ampere: {
            type: DataTypes.DECIMAL.UNSIGNED,
            allowNull: false
        },
        voltage: {
            type: DataTypes.DECIMAL.UNSIGNED,
            allowNull: false
        },
        price_rate: {
            type: DataTypes.DECIMAL(3, 2),
            allowNull: false
        },
        image_file: {
            type: DataTypes.STRING(16)
        }
    });

    ChargingStationModel.associate = (models) => {
        ChargingStationModel.hasMany(models.ChargingStation, {
            foreignKey: "model_id"
        });
    };

    return ChargingStationModel;
}