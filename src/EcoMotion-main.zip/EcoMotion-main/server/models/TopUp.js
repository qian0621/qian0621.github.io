module.exports = (sequelize, DataTypes) => {
    const TopUp = sequelize.define("TopUp", {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      amount: {
        type: DataTypes.FLOAT,
        allowNull: true,
      },
      stripe_client_secret: {
        type: DataTypes.STRING(255),
        allowNull: false,
      },
    });
    TopUp.associate = (models) => {
        TopUp.belongsTo(models.Card, {
            foreignKey: "card_id",
            allowNull: false,
            onDelete: "RESTRICT"
        });
    };
    return TopUp;
  };
