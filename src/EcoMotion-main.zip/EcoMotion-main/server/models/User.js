module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define("User", {
        email: {
            type: DataTypes.STRING,
            allowNull: false
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false
        },
        role: {
            type: DataTypes.STRING, // This field will store either 'admin' or 'customer'
            defaultValue: 'customer', // Default role will be 'customer'
          },
        balance: {
            type: DataTypes.FLOAT,
            allowNull: true,
          },
        
    });

    User.associate = (models) => {
        User.hasMany(models.Card, {
            foreignKey: "user_id"
        });
    };
    return User;
}
