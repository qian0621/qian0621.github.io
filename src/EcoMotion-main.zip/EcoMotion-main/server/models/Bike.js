module.exports = (sequelize, DataTypes) => {
    const Bike = sequelize.define("Bike", {
        status: {
            type: DataTypes.ENUM,
            values: ["available", "unavailable", "retired", "maintenance"],
            allowNull: false
        },
        battery: {
            type: DataTypes.INTEGER.UNSIGNED
        }, 
        charging: {
            type: DataTypes.BOOLEAN
        },
        location: {
            type: DataTypes.GEOMETRY('POINT', 4326),
        }
    });

    Bike.associate = (models) => {
        Bike.belongsTo(models.BikeModel, {
            foreignKey: "model_id",
            allowNull: false,
            onDelete: "RESTRICT"
        });
    };

    return Bike;
}
