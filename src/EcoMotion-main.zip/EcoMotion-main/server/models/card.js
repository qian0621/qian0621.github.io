module.exports = (sequelize, DataTypes) => {
    const Card = sequelize.define("Card", {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      card_number: {
        type: DataTypes.STRING(225),
        allowNull: false,
      },
      cardholder_name: {
        type: DataTypes.STRING(255),
        allowNull: false,
      },
      exp_month: {
        type: DataTypes.STRING(4),
        allowNull: false,
      },
      exp_year: {
        type: DataTypes.STRING(4),
        allowNull: false,
      },
      cvv: {
        type: DataTypes.STRING(4),
        allowNull: false,
      },
      balance: {
        type: DataTypes.FLOAT,
        allowNull: true,
      },
      
    });
    Card.associate = (models) => {
        Card.belongsTo(models.User, {
            foreignKey: "user_id",
            allowNull: false,
            onDelete: "RESTRICT"
        });
    };
    Card.associate = (models) => {
      Card.hasMany(models.TopUp, {
          foreignKey: "card_id"
      });
  };
    return Card;
  };
