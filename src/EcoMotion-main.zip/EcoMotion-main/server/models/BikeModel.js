module.exports = (sequelize, DataTypes) => {
    const BikeModel = sequelize.define("BikeModel", {
        name: {
            type: DataTypes.STRING(100),
            allowNull: false,
            unique: true
        },
        battery_per_km: {
            type: DataTypes.DECIMAL.UNSIGNED,
            allowNull: false
        },
        price_rate: {
            type: DataTypes.DECIMAL(3, 2),
            allowNull: false
        },
        image_file: {
            type: DataTypes.STRING(16)
        }
    });

    BikeModel.associate = (models) => {
        BikeModel.hasMany(models.Bike, {
            foreignKey: "model_id"
        });
    };

    return BikeModel;
}