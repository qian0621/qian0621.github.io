module.exports = (sequelize, DataTypes) => {
    const CustomerFavouriteRoute = sequelize.define('CustomerFavouriteRoute', {
      id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      start: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      end: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    });
  
    return CustomerFavouriteRoute;
  };
  