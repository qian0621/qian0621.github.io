module.exports = (sequelize, DataTypes) => {
  const TimeDifference = sequelize.define("TimeDifference", {
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    start_time: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    finish: {
      type: DataTypes.BOOLEAN,
      allowNull: true,
    },
  });

  return TimeDifference;
};
