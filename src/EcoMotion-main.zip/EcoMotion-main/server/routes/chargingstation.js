const express = require('express');
const router = express.Router();
const { ChargingStationModel, ChargingStation, Sequelize } = require('../models');
const yup = require("yup");
const { validateToken } = require('../middlewares/auth');

function procContinuous(str, parse) {
    let arr = str.split('-', 2);
    arr.forEach(parse);
    if (arr.some(isNaN)) {
        return;
    } else if (arr.length === 1) {
        return arr[0];
    } else {
        return { [Sequelize.Op.between]: [arr[0], arr[1]] };
    }
}

function queryProcSearch(query_string, locNotNull) {
    var { status, battery, charging, model } = query_string;

    // Build the search criteria object based on the provided query parameters
    const searchCriteria = [];

    if (status) {
        status = status.split(',');
        status.forEach((stat) => stat.toLowerCase());

        searchCriteria.push({status: 
            (status.length === 1) 
                ? status[0] 
                : {[Sequelize.Op.or]: status}
        });
    }
    if (battery) {
        searchCriteria.push({battery: procContinuous(battery, parseInt)});
    }
    if (charging !== undefined) {
        searchCriteria.push({charging: 
            (charging === "") || Boolean(charging)
        });
    }
    if (locNotNull) {
        searchCriteria.push({location: {[Sequelize.Op.not]: null}});
    }
    if (model) {
        searchCriteria.push({model: 
            { [Sequelize.Op.substring]: model } 
        });
    }
    return {[Sequelize.Op.and]: searchCriteria};
}

function arrayToPoint(arr) {return Sequelize.fn('ST_PointFromText', `Point(${arr.join(' ')})`, 4326);}

const geodetic_coor = yup.tuple([
    yup.number().max(90, "Latitude out of range").min(-90, "Latitude out of range"),
    yup.number().max(180, "Longitude out of range").min(-180, "Longitude out of range")
])

const validation = {
    status: yup.string().trim().lowercase().oneOf(["available", "unavailable", "maintenance", "retired"]),
    battery: yup.number().integer().positive().min(0).max(100),
    charging: yup.boolean(),
    location: geodetic_coor
};

const patchValidationSchema = yup.object(validation);
const editAttrs = Object.keys(validation);

for (const key in validation) {
    validation[key] = validation[key].required();
}
// const putValidationSchema = yup.object(validation);

validation.model_id = yup.number().integer().required()
const postValidationSchema = yup.object(validation);
const createAttrs = Object.keys(validation);

async function coorToPoint(str) {
    if (str) { 
        try {
            var coor = await geodetic_coor.validate(str?.split(','));
        } catch (err) {
            return;
        }
        return arrayToPoint(coor);
    }
}

function onlyAttrs(obj, attrs) {
    for (const key in obj) {
        if (!attrs.includes(key)) delete obj[key]
    }
}

router.post("/", validateToken, async (req, res) => {
    try {
        data = await postValidationSchema.validate(req.body,
            { abortEarly: false });
    } catch (err) {
        console.error(err);
        res.status(400).json({ errors: err.errors });
        return;
    }

    let chargingstationModel = await ChargingStationModel.findByPk(data.model_id);
    if (!chargingstationModel) {
        res.status(404).json({ message: "No such charging station model" });
        return;
    }
    onlyAttrs(data, createAttrs);
    data.location = arrayToPoint(data.location);
    // data.location = { type: 'Point', coordinates: data.location };
    // , crs: { type: "name", properties: { name: 'EPSG:4326'} }
    let result = await ChargingStation.create(data);
    res.json(result);
});

router.get("/", async (req, res) => {
    var dist_from;
    const getAttr = ['id', 'model_id', 'status', 'battery', 'charging', 'location']
    const order = [['createdAt', 'DESC']];
    const near = await coorToPoint(req.query.near)
    if (near) {
        dist_from= 'dist_from'
        getAttr.push([Sequelize.fn('ST_Distance', Sequelize.col('location'), near), dist_from]);
        order.unshift(dist_from);
    } 
    var searchFunc;
    if (req.query.nearest === "" || req.query.nearest) {
        searchFunc = "findOne"; 
    } else {
        searchFunc = "findAll";
    }
    let list = await ChargingStation[searchFunc]({
        where: queryProcSearch(req.query, dist_from), 
        attributes: getAttr,
        order: order,
        raw: true
    });
    res.json(list);
});

router.get("/locations", async (req, res) => {
    //todo: if customer only status available and charging
    var dist_from;
    const getAttr = ['id', 'location']
    const order = [];
    const near = await coorToPoint(req.query.near)
    if (near) {
        dist_from= 'dist_from'
        getAttr.push([Sequelize.fn('ST_Distance', Sequelize.col('location'), near), dist_from]);
        order.unshift(dist_from);
    }
    var searchFunc;
    if (req.query.nearest === "" || req.query.nearest) {
        searchFunc = "findOne"; 
    } else {
        searchFunc = "findAll";
    }
    let list = await ChargingStation[searchFunc]({
        where: queryProcSearch(req.query, true), 
        attributes: getAttr,
        order: order,
        raw: true,
    });
    res.json(list);
});

router.get("/:id", async (req, res) => {
    let id = req.params.id;
    let chargingstation = await ChargingStation.findByPk(id, {
        attributes: ['id', 'battery', 'charging', 'location', 'status'],
        include: { 
            model: ChargingStationModel, 
            attributes: ['name', 'ampere', 'voltage', 'price_rate', 'image_file'] 
        }
    });
    // Check id not found
    if (!chargingstation) {
        res.sendStatus(404);
        return;
    }
    res.json(chargingstation);
});

router.patch("/:id", validateToken, async (req, res) => {
    let id = req.params.id;
    // Check id not found
    let chargingstation = await ChargingStation.findByPk(id);
    if (!chargingstation) {
        res.sendStatus(404);
        return;
    }

    // Validate request body
    try {
        data = await patchValidationSchema.validate(req.body,
            { abortEarly: false }
        );
    } catch (err) {
        console.error(err);
        res.status(400).json({ errors: err.errors });
        return;
    }
    onlyAttrs(data, editAttrs);
    if (data.location) data.location = arrayToPoint(data.location);
    let num = await ChargingStation.update(data, {
        where: { id: id }
    });
    if (num == 1) {
        res.json({
            message: "Charging Station was updated successfully."
        });
    }
    else {
        res.status(400).json({
            message: `Cannot update Charging Station with id ${id}.`
        });
    }
});

router.delete("/:id", validateToken, async (req, res) => {
    let id = req.params.id;
    // Check id not found
    let chargingstation  = await ChargingStation.findByPk(id);
    if (!chargingstation) {
        res.sendStatus(404);
        return;
    }
    try {
        let num = await ChargingStation.destroy({
            where: { id: id }
        })
        if (num == 1) {
            res.json({
                message: "Charging Station was deleted successfully."
            });
        }
        else {
            res.status(400).json({
                message: `Cannot delete Charging Station with id ${id}.`
            });
        }
    } catch (err) {
        if (error instanceof Sequelize.ForeignKeyConstraintError) {
            res.status(409).json({
                message: `Cannot delete Charging Station with id ${id} due to foreign key constraint violation.`
            });
        } else {
            res.status(500).json({
                message: "An error occurred while processing the request."
            });
        }
    }
});

module.exports = router;