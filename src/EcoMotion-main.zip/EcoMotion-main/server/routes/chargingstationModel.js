const express = require('express');
const router = express.Router();
const { ChargingStationModel, ChargingStation, Sequelize } = require('../models');
const yup = require("yup");
const { validateToken } = require('../middlewares/auth');

const validationSchema = yup.object({
    name: yup.string().trim().min(1).max(100).required(),
    ampere: yup.number().min(16).max(48).required(),
    voltage: yup.number().min(220).max(480).required(),
    price_rate: yup.number().max(9.99).required()
});

router.post("/", validateToken, async (req, res) => {
    // Validate request body
    try {
        var data = await validationSchema.validate(req.body,
            { abortEarly: false });
    }
    catch (err) {
        console.error(err);
        res.status(400).json({ errors: err.errors });
        return;
    }

    // check name duplicate
    let sameNameChargingStationModel = await ChargingStationModel.findOne({
        where: { name: data.name },
    });
    if (sameNameChargingStationModel) {
        res.status(409).json({ message: 'A Charging Station Model with the same name already exists' });
        return;
    }

    let result = await ChargingStationModel.create(data);
    res.json(result);
});

router.get("/", async (req, res) => {
    let list = await ChargingStationModel.findAll({
        attributes: ['id', 'name']
    });
    res.json(list);
});

router.get("/details", async (req, res) => {
    const { name, ampere, voltage, price_rate } = req.query;

    // Build the search criteria object based on the provided query parameters
    const searchCriteria = {};

    if (name) {
      searchCriteria.name = { [Sequelize.Op.like]: `%${name}%` };
    }
    if (ampere) {
      searchCriteria.ampere = parseFloat(ampere);
    }
    if (voltage) {
        searchCriteria.voltage = parseFloat(voltage);
    }
    if (price_rate) {
      searchCriteria.price_rate = parseFloat(price_rate);
    }

    let list = await ChargingStationModel.findAll({
        where: searchCriteria,
        attributes: ['id', 'name', 'ampere', 'voltage', 'price_rate', 'image_file', 
            [Sequelize.fn('COUNT', Sequelize.col('ChargingStations.id')), 'total_chargingstations']
        ],
        include: { 
            model: ChargingStation,
            attributes: [],
            required: false, // Use LEFT OUTER JOIN
            raw: true
        }, 
        group: ['id'],
        order: [['createdAt', 'DESC']]
    });
    res.json(list);
});

router.get("/:id", async (req, res) => {
    let id = req.params.id;
    let chargingstationModel = await ChargingStationModel.findByPk(id);
    // Check id not found
    if (!chargingstationModel) {
        res.sendStatus(404);
        return;
    }
    res.json(chargingstationModel);
});

router.put("/:id", validateToken, async (req, res) => {
    let id = req.params.id;
    // Check id not found
    let chargingstationModel = await ChargingStationModel.findByPk(id);
    if (!chargingstationModel) {
        res.sendStatus(404);
        return;
    }
    // Validate request body
    try {
        var data = await validationSchema.validate(req.body,
            { abortEarly: false });
    }
    catch (err) {
        console.error(err);
        res.status(400).json({ errors: err.errors });
        return;
    }

    //check name duplicate
    let sameNameChargingStationModels = await ChargingStationModel.findAll({
        where: { name: data.name },
    });
    if (sameNameChargingStationModels && (sameNameChargingStationModels.length > 1 && sameNameChargingStationModels[0]?.id != data.id)) {
        res.status(409).json({ message: 'Another Charging Station Model with the same name already exists' });
        return;
    }

    let num = await ChargingStationModel.update(data, {
        where: { id: id }
    });
    if (num == 1) {
        res.json({
            message: "Charging Station Model was updated successfully."
        });
    }
    else {
        res.status(400).json({
            message: `Cannot update Charging Station Model with id ${id}}.`
        });
    }
});

router.delete("/:id", validateToken, async (req, res) => {
    let id = req.params.id;
    // Check id not found
    let chargingstationModel = await ChargingStationModel.findByPk(id);
    if (!chargingstationModel) {
        res.sendStatus(404);
        return;
    }


    try {
        let num = await ChargingStationModel.destroy({
            where: { id: id }
        });
        if (num == 1) {
            res.json({
                message: "Charging Station Model was deleted successfully."
            });
        } else {
            res.status(400).json({
                message: `Cannot delete Charging Station Model with id ${id}.`
            });
        }
    } catch (error) {
        if (error instanceof Sequelize.ForeignKeyConstraintError) {
            res.status(409).json({
                message: `Cannot delete Charging Station Model with id ${id} due to foreign key constraint violation.`
            });
        } else {
            res.status(500).json({
                message: "An error occurred while processing the request."
            });
        }
    }
});

module.exports = router;