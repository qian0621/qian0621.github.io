const express = require('express');
const yup = require('yup');
const router = express.Router();
const { CustomerFavouriteRoute } = require('../models');

// POST a new favourite route
router.post('/', (req, res) => {
  const { start, end } = req.body;
  console.log({
    start,
    end,
  });

  CustomerFavouriteRoute.create({
    start,
    end,
  })
    .then((customerfavouriteroute) => {
      res.status(201).json({ message: 'Favourite route created successfully', customerfavouriteroute });
    })
    .catch((error) => {
      console.error('Error creating favourite route:', error);
      res.status(500).json({ error: 'Internal server error' });
    });
});

// GET all CustomerFavouriteRoutes
router.get('/', async (req, res) => {
  try {
    // Fetch all accounts from the database
    const customerfavouriteroutes = await CustomerFavouriteRoute.findAll({
      attributes: ['id', 'start', 'end'],
    });

    res.json(customerfavouriteroutes);
  } catch (error) {
    console.error('Error fetching favourite routes:', error);
    res.status(500).json({ message: 'Failed to fetch favourite routes' });
  }
});

// GET a specific favourite route by ID
router.get('/:id', (req, res) => {
  const { id } = req.params;

  CustomerFavouriteRoute.findByPk(id)
    .then((customerfavouriteroute) => {
      if (!customerfavouriteroute) {
        return res.status(404).json({ error: 'Favourite route not found' });
      }
      res.json(customerfavouriteroute);
    })
    .catch((error) => {
      console.error('Error retrieving favourite route:', error);
      res.status(500).json({ error: 'Internal server error' });
    });
});

// PUT update a report
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { start, end } = req.body;

  CustomerFavouriteRoute.findByPk(id)
    .then((customerfavouriteroute) => {
      if (!customerfavouriteroute) {
        return res.status(404).json({ error: 'Favourite route not found' });
      }

      // Update the favourite route with the new data
      customerfavouriteroute.start = start;
      customerfavouriteroute.end = end;

      // Save the updated favourite route
      return customerfavouriteroute.save();
    })
    .then((updatedCustomerFavouriteRoute) => {
      res.json(updatedCustomerFavouriteRoute);
    })
    .catch((error) => {
      console.error('Error updating favourite route:', error);
      res.status(500).json({ error: 'Internal server error' });
    });
});

// DELETE a favourite route
router.delete('/:id', (req, res) => {
  const { id } = req.params;

  CustomerFavouriteRoute.destroy({
    where: { id },
  })
    .then((deletedCount) => {
      if (deletedCount === 0) {
        return res.status(404).json({ error: 'Favourite route not found' });
      }
      res.json({ message: 'Favourite route deleted successfully' });
    })
    .catch((error) => {
      console.error('Error deleting favourite route:', error);
      res.status(500).json({ error: 'Internal server error' });
    });
});

module.exports = router;
