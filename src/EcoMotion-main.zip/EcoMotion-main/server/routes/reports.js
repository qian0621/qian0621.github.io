const express = require('express');
const yup = require('yup');
const router = express.Router();
const { Report } = require('../models');

// POST a new report
router.post('/', (req, res) => {
  const { name, contactNumber, datetimeOfReport, selectedImage, otherDamages } = req.body;
  console.log({
    name,
    contactNumber,
    datetimeOfReport,
    selectedImage,
    otherDamages,
  });

  Report.create({
    name,
    contactNumber,
    datetimeOfReport,
    selectedImage,
    otherDamages,
  })
    .then((report) => {
      res.status(201).json({ message: 'Report created successfully', report });
    })
    .catch((error) => {
      console.error('Error creating report:', error);
      res.status(500).json({ error: 'Internal server error' });
    });
});

// GET all reports
router.get('/', async (req, res) => {
  try {
    // Fetch all accounts from the database
    const reports = await Report.findAll({
      attributes: ['id', 'name', 'contactNumber', 'datetimeOfReport', 'selectedImage', 'otherDamages'],
    });

    res.json(reports);
  } catch (error) {
    console.error('Error fetching reports:', error);
    res.status(500).json({ message: 'Failed to fetch reports' });
  }
});

// GET a specific report by ID
router.get('/:id', (req, res) => {
  const { id } = req.params;

  Report.findByPk(id)
    .then((report) => {
      if (!report) {
        return res.status(404).json({ error: 'Report not found' });
      }
      res.json(report);
    })
    .catch((error) => {
      console.error('Error retrieving report:', error);
      res.status(500).json({ error: 'Internal server error' });
    });
});

// PUT update a report
router.put('/:id', (req, res) => {
  const { id } = req.params;
  const { name, contactNumber, datetimeOfReport, selectedImage, otherDamages } = req.body;

  Report.findByPk(id)
    .then((report) => {
      if (!report) {
        return res.status(404).json({ error: 'Report not found' });
      }

      // Update the report with the new data
      report.name = name;
      report.contactNumber = contactNumber;
      report.datetimeOfReport = datetimeOfReport;
      report.selectedImage = selectedImage;
      report.otherDamages = otherDamages;

      // Save the updated report
      return report.save();
    })
    .then((updatedReport) => {
      res.json(updatedReport);
    })
    .catch((error) => {
      console.error('Error updating report:', error);
      res.status(500).json({ error: 'Internal server error' });
    });
});

// DELETE a report
router.delete('/:id', (req, res) => {
  const { id } = req.params;

  Report.destroy({
    where: { id },
  })
    .then((deletedCount) => {
      if (deletedCount === 0) {
        return res.status(404).json({ error: 'Report not found' });
      }
      res.json({ message: 'Report deleted successfully' });
    })
    .catch((error) => {
      console.error('Error deleting report:', error);
      res.status(500).json({ error: 'Internal server error' });
    });
});

module.exports = router;
