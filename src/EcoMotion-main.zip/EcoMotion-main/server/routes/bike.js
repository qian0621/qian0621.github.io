const express = require('express');
const router = express.Router();
const { BikeModel, Bike, Sequelize } = require('../models');
const yup = require("yup");
const { validateToken } = require('../middlewares/auth');

function procContinuous(str, parse) {
    var not;
    if (str === "") {
        not = 0;
    } else if (str?.[0] === "!") {
        not = parse(str.substring(1));
    } else if (str) {
        let arr = str.split('-', 2);
        arr.forEach(parse);
        if (arr.some(isNaN)) {
            return;
        } else if (arr.length === 1) {
            return arr[0];
        } else {
            return { [Sequelize.Op.between]: [arr[0], arr[1]] };
        }
    }
    if (!isNaN(not)) return { [Sequelize.Op.ne]: not };
}

function queryProcSearch(query_string, locNotNull) {
    var { status, battery, charging, model } = query_string;

    // Build the search criteria object based on the provided query parameters
    const searchCriteria = [];

    if (status) {
        status = status.split(',');
        status.forEach((stat) => stat.toLowerCase());

        searchCriteria.push({status: 
            (status.length === 1) 
                ? status[0] 
                : {[Sequelize.Op.or]: status}
        });
    }
    const batteryCondition = procContinuous(battery, parseInt);
    if (batteryCondition) {
        searchCriteria.push({battery: batteryCondition});
    } // else bad request?
    if (charging !== undefined) {
        searchCriteria.push({charging: 
            (charging === "") || Boolean(charging)
        });
    }
    if (locNotNull) {
        searchCriteria.push({location: {[Sequelize.Op.not]: null}});
    }
    if (model) {
        searchCriteria.push({model: 
            { [Sequelize.Op.substring]: model } 
        });
    }
    return {[Sequelize.Op.and]: searchCriteria};
}

function arrayToPoint(arr) {return Sequelize.fn('ST_PointFromText', `Point(${arr.join(' ')})`, 4326);}

const geodetic_coor = yup.tuple([
    yup.number().max(90, "Latitude out of range").min(-90, "Latitude out of range"),
    yup.number().max(180, "Longitude out of range").min(-180, "Longitude out of range")
])

const validation = {
    status: yup.string().trim().lowercase().oneOf(["available", "unavailable", "maintenance", "retired"]),
    battery: yup.number().integer().positive().min(0).max(100),
    charging: yup.boolean(),
    location: geodetic_coor
};

const patchValidationSchema = yup.object(validation);
const editAttrs = Object.keys(validation);

for (const key in validation) {
    validation[key] = validation[key].required();
}
// const putValidationSchema = yup.object(validation);

validation.model_id = yup.number().integer().required()
const postValidationSchema = yup.object(validation);
const createAttrs = Object.keys(validation);

async function coorToPoint(str) {
    if (str) { 
        try {
            var coor = await geodetic_coor.validate(str?.split(','));
        } catch (err) {
            return;
        }
        return arrayToPoint(coor);
    }
}

function onlyAttrs(obj, attrs) {
    for (const key in obj) {
        if (!attrs.includes(key)) delete obj[key]
    }
}

async function selectBike({query, res, getAttr, order = [], nearest=false}) {
    var dist_from;
    const near = await coorToPoint(query.near)
    var searchFunc = "findAll";
    if (near) {
        dist_from= 'dist_from'
        getAttr.push([Sequelize.fn('ST_Distance', Sequelize.col('location'), near), dist_from]);
        order.unshift(dist_from);
        
        if (nearest || query.nearest === "" || query.nearest) {
            searchFunc = "findOne";
        }
    } else {
        if (nearest) res.sendStatus(400);
    }
    let list = await Bike[searchFunc]({
        where: queryProcSearch(query, dist_from), 
        attributes: getAttr,
        order: order,
        raw: true
    });
    res.json(list);
}

router.post("/", validateToken, async (req, res) => {
    try {
        data = await postValidationSchema.validate(req.body,
            { abortEarly: false });
    } catch (err) {
        console.error(err);
        res.status(400).json({ errors: err.errors });
        return;
    }

    let bikeModel = await BikeModel.findByPk(data.model_id);
    if (!bikeModel) {
        res.status(404).json({ message: "No such bike model" });
        return;
    }
    onlyAttrs(data, createAttrs);
    data.location = arrayToPoint(data.location);
    // data.location = { type: 'Point', coordinates: data.location };
    // , crs: { type: "name", properties: { name: 'EPSG:4326'} }
    let result = await Bike.create(data);
    res.json(result);
});

router.get("/", async (req, res) => selectBike({
    query: req.query, 
    res: res, 
    getAttr: ['id', 'model_id', 'status', 'battery', 'charging', 'location'], 
    order: [['createdAt', 'DESC']]
}));

//todo: if customer only status available and charging
router.get("/locations", async (req, res) => selectBike({
    query: req.query, 
    res: res, 
    getAttr: ['id', 'location']
}));

router.get("/nearest", async (req, res) => selectBike({
    query: req.query, 
    res: res, 
    getAttr: ['id'],
    nearest: true
}));

router.get("/:id", async (req, res) => {
    let id = req.params.id;
    let bike = await Bike.findByPk(id, {
        attributes: ['id', 'battery', 'charging', 'location', 'status'],
        include: { 
            model: BikeModel, 
            attributes: ['name', 'battery_per_km', 'price_rate', 'image_file'] 
        }
    });
    // Check id not found
    if (!bike) {
        res.sendStatus(404);
        return;
    }
    if (req.query.exists === '' || req.query.exists) {
        res.json(true);
        return;
    } else {
        res.json(bike);
    }
});

router.patch("/:id", validateToken, async (req, res) => {
    let id = req.params.id;
    // Check id not found
    let bike = await Bike.findByPk(id);
    if (!bike) {
        res.sendStatus(404);
        return;
    }

    // Validate request body
    try {
        data = await patchValidationSchema.validate(req.body,
            { abortEarly: false }
        );
    } catch (err) {
        console.error(err);
        res.status(400).json({ errors: err.errors });
        return;
    }
    onlyAttrs(data, editAttrs);
    if (data.location) data.location = arrayToPoint(data.location);
    let num = await Bike.update(data, {
        where: { id: id }
    });
    if (num == 1) {
        res.json({
            message: "Bike was updated successfully."
        });
    }
    else {
        res.status(400).json({
            message: `Cannot update Bike with id ${id}.`
        });
    }
});

router.delete("/:id", validateToken, async (req, res) => {
    let id = req.params.id;
    // Check id not found
    let bike = await Bike.findByPk(id);
    if (!bike) {
        res.sendStatus(404);
        return;
    }
    try {
        let num = await Bike.destroy({
            where: { id: id }
        })
        if (num == 1) {
            res.json({
                message: "Bike was deleted successfully."
            });
        }
        else {
            res.status(400).json({
                message: `Cannot delete Bike with id ${id}.`
            });
        }
    } catch (err) {
        if (error instanceof Sequelize.ForeignKeyConstraintError) {
            res.status(409).json({
                message: `Cannot delete Bike with id ${id} due to foreign key constraint violation.`
            });
        } else {
            res.status(500).json({
                message: "An error occurred while processing the request."
            });
        }
    }
});

module.exports = router;