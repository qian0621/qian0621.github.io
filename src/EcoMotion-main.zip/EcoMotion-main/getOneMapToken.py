import requests
from dotenv import load_dotenv
from os import getenv

url = "https://www.onemap.gov.sg/api/auth/post/getToken"
load_dotenv()
payload = {
    "email": getenv('EMAIL'),
    "password": getenv('PASSWORD')
}
response = requests.request("POST", url, json=payload)
print(response.text)