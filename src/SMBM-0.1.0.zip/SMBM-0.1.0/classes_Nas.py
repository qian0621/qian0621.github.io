from datetime import date
from flask import session
import shelve


class Reward:
    voucher: str
    points: int

    def __init__(self, customer):
        self.date = date.today()
        self.used = False
        self.customer = customer
        self.deductpoints(customer)

    def deductpoints(self, customer):
        customer.use_points(self.points)
        customer.update_db()


class Guidedtour10(Reward):
    voucher = "10% off for guided tour"
    points = 15

    @staticmethod
    def discount(subtotal):
        return -(subtotal * 0.1)


class Guidedtour20(Reward):
    voucher = "20% off for guided tour"
    points = 25

    @staticmethod
    def discount(subtotal):
        return -(subtotal * 0.2)


class Cafe1(Reward):
    voucher = "$1 off any dish in café "
    points = 5

    @staticmethod
    def discount(subtotal):
        return -1


class Cafe2off(Reward):
    voucher = "$2 off any dish in café"
    points = 9

    @staticmethod
    def discount(subtotal):
        return -2


class Workshop10(Reward):
    voucher = "10% off for workshop"
    points = 17

    @staticmethod
    def discount(subtotal):
        return -(subtotal * 0.1)


class Workshop20(Reward):
    voucher = "20% off for workshop"
    points = 30

    @staticmethod
    def discount(subtotal):
        return -(subtotal * 0.2)
